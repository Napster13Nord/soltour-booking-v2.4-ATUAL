//Impersonation Script
function ImpersonatePos(netherUrl, session, pointOfSaleId) {
  var impersonatedInput = document.getElementById("header-impersonated-point-of-sale")
  var impersonatedLine = document.querySelector("#header-impersonated-point-of-sale-line.hidden")
  var impersonatedInputMobile = document.getElementById("header-impersonated-point-of-sale-mobile")
  var impersonatedLineMobile = document.getElementById("header-impersonated-point-of-sale-line-mobile.hidden")

  var request = new XMLHttpRequest();

  request.open(
    "PUT",
    netherUrl + "/session/" + session + "/impersonated/point-of-sale/" + pointOfSaleId,
    true
  );

  request.setRequestHeader("Content-Type", "application/json");

  request.onload = function () {
    if (this.status >= 200 && this.status < 400) {
      if (impersonatedLine) impersonatedLine.classList.remove("hidden")
      impersonatedInput.innerHTML = pointOfSaleId
      if (impersonatedLineMobile) impersonatedLineMobile.classList.remove("hidden")
      impersonatedInputMobile.innerHTML = pointOfSaleId
      PointOfSaleEvent(pointOfSaleId);
    } else {
      impersonatedLine.classList.remove("hidden")
      impersonatedInput.innerHTML = "Impersonation Error"
      impersonatedLineMobile.classList.remove("hidden")
      impersonatedInputMobile.innerHTML = "Impersonation Error"
    }
  };

  request.send();
}

function LoadPointOfSaleImpersonated() {
  if (document.getElementById("header-impersonated-point-of-sale").innerHTML != null) {
    PointOfSaleEvent(document.getElementById("header-impersonated-point-of-sale").innerHTML)
  }
}

//Load Agency Searcher JS
function loadAgencySelector(session, netherUrl) {
  var agencySearcherValue = "";
  var agencySearcher = document.querySelector('#agency-searcher');
  var agencySearcherSuggestions = document.querySelector('.agency-suggestions ul');

  var debounce = function (func, wait) {
    var timeout;

    return function executedFunction() {
      var later = function () {
        clearTimeout(timeout);
        func();
      };

      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  };

  function returnedFunction(e) {
    agencySearcherValue = e.currentTarget.value;
  };

  var getData = debounce(function () {
    agencySearcherSuggestions.innerHTML = '';
    if (agencySearcherValue.length > 0) {
      var request = new XMLHttpRequest();

      request.open(
        "GET",
        netherUrl + "/point-of-sale/filter/header-stp?filter=" + agencySearcherValue + "&take=20&skip=0&session=" + session,
        true
      );

      request.setRequestHeader("Content-Type", "application/json");

      request.onload = function () {
        if (this.status >= 200 && this.status < 400) {
          var responseData = JSON.parse(request.response);
          showSuggestions(responseData.pointsOfSale)
        }
      };

      request.send();
    } else {
      defaultUserPos.forEach(pos => {
        agencySearcherSuggestions.innerHTML += "<li id=\"" + pos.id + "\">" + pos.content + "</li>";
      })
      agencySearcherSuggestions.classList.add('has-suggestions');
    }
  }, 1000)

  var defaultUserPos = [];

  function showSuggestions(results) {
    agencySearcherSuggestions.innerHTML = '';

    if (results.length > 0) {
      for (i = 0; i < results.length; i++) {
        var pointOfSale = results[i];
        var pointOfSaleName = "";
        if (pointOfSale.maps.length > 0) {
          pointOfSaleName = "<b>Name: </b><br>" + pointOfSale.name + "<br> <b>Address:</b> <br>" + pointOfSale.location.address + ", " + pointOfSale.location.cityName + "<br>" + "<b>ID:</b><br>" + pointOfSale.maps[0].externalId
        } else {
          pointOfSaleName = "<b>Name: </b><br>" + pointOfSale.name + "<br> <b>Address:</b> <br>" + pointOfSale.location.address + ", " + pointOfSale.location.cityName + "<br>" + "<b>ID:</b><br>" + pointOfSale.id
        }

        pointOfSale.id = pointOfSale.maps.length > 0 ?
          pointOfSale.maps[0].externalId :
          pointOfSale.id

        agencySearcherSuggestions.innerHTML += "<li id=\"" + pointOfSale.id + "\">" + pointOfSaleName + "</li>";
      }
      agencySearcherSuggestions.classList.add('has-suggestions');
    } else {
      results = [];
      agencySearcherSuggestions.innerHTML = '';
      agencySearcherSuggestions.classList.add('has-suggestions');
    }
  }

  function useSuggestion(e) {
    agencySearcher.value = e.target.innerText.split("Name:")[1].split("Address:")[0];
    ImpersonatePos(netherUrl, session, e.target.id);
    agencySearcherSuggestions.innerHTML = '';
    agencySearcherSuggestions.classList.remove('has-suggestions');
  }

  function SetDefaultUserPos() {
    agencySearcherSuggestions.querySelectorAll('li').forEach(pos => {
      defaultUserPos.push({
        id: pos.id,
        content: pos.innerHTML
      })
    })
  }

  if (!agencySearcher.disabled) {
    SetDefaultUserPos()
    agencySearcher.addEventListener('keyup', returnedFunction);
    agencySearcher.addEventListener('keyup', getData);
    agencySearcher.addEventListener('click', returnedFunction);
    agencySearcher.addEventListener('click', getData);
    agencySearcherSuggestions.addEventListener('click', useSuggestion);
  }
}

// Load Event Emmiter JS
function fireEvent(name, object) {
  var event = new CustomEvent(name, object);
  document.dispatchEvent(event);
}

function emitEvents() {
  function ProvinceEvent() {
    var listItems = document.querySelectorAll(".c-b2b-header__location-selection-list-B2B li");

    listItems.forEach(function (item) {
      item.addEventListener("click", function () {
        var link = this.querySelector("a");
        fireEvent("SelectedProvince", {
          detail: link.id
        });
      });
    });
  }

  function MarketEvent() {
    var locations = document.querySelectorAll(".c-b2b-header__market-selection-list a");

    locations.forEach(function (link) {
      link.addEventListener("click", function () {
        fireEvent("SelectedMarket", {
          detail: this.id
        });
      });
    });
  }

  ProvinceEvent();
  MarketEvent();
}

function PointOfSaleEvent(pointOfSaleId) {
  fireEvent("SelectedPointOfSale", {
    detail: pointOfSaleId
  });
}

function EditorModeEvent() {
  fireEvent("SwitchEditorMode", {
    detail: true
  });
}

// Load RefreshSession
function SessionRefresh(session, netherUrl) {
  var request = new XMLHttpRequest();

  request.open(
    "PUT",
    netherUrl + "/session/" + session + "/refresh"
  );

  request.setRequestHeader("Content-Type", "application/json");

  request.onload = function () {
    if (this.status == 401 || this.status == 500 || this.status == 404) {
      window.location.href = "https://login.travelance.club/logout";
    }
  };

  request.send();
}

function getPageSection() {
  const getLastSegment = (url) => {
    const cleanUrl = url.split('?')[0];
    const segments = cleanUrl.split('/');
    return segments.pop() || '';
  };

  return getLastSegment(window.location.href);
}

function mapUserType(userType) {
  switch (userType) {
    case "INTERNAL":
      return "internal";
    case "ADMIN":
      return "agent admin";
    case "AGENT":
      return "agent basic";
    default:
      return userType;
  }
}

// UserInfo Object
function UserInfo(dataLayer) {
  return {
    UserName : dataLayer.userName,
    UserEmail: dataLayer.userEmail,
    UserType: mapUserType(dataLayer.userType),
    UserIsInternal: dataLayer.userIsInternal,
    SessionId: dataLayer.sessionId,
    PointOfSaleId: dataLayer.pointOfSaleId,
    PointOfSaleName: dataLayer.pointOfSaleName,
    Market: dataLayer.market,
    PointOfSaleCode: dataLayer.pointOfSaleCode,
    UserCode: dataLayer.userCode,
    OriginCode: dataLayer.originCode,
    ProvinceCode: dataLayer.provinceCode
  }
}

// Add DataLayer
function AddDataLayer(dataLayer){
  if (window.dataLayer){
    UserInfo = UserInfo(dataLayer);
    window.dataLayer.push({'event': 'UserInformation', UserInfo});

    fireEvent("DataLayerLoaded", {
      detail: true
    });
  }
}

// Add events DataLayer
function trackClick(data, actionType) {

  window.dataLayer.push({'event': 'click', 
  sectionData:({
    actionType: "select_"+actionType,
    pageSection: getPageSection(),
    contentType: data.text || data.name,
  }),
    ...UserInfo,
  });

  fireEvent("DataLayerLoaded", {
    detail: true
  });  
}

// Load Header JS
function loadHeader(session, netherUrl) {
  var container = document.getElementById("header-stp-b2b-container");
  container.innerHTML = '<!DOCTYPE html> <html lang="en"> <head> <meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0"> <title>Document</title> <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&amp;display=swap" rel="stylesheet"> <style> :root{ --bronze: #AF7D45; --gold: #FBBC0C; --silver: #C6C6C6; --initial: #E00613; --color-travelance:#70737A; --light-grey01:#A8A8A7; --light-grey02:#C6C6C6; --light-grey03:#F6F6F6; --low:#00837D; --medium:#362DB8; --premium:#A3050E; --initial:#303030; --yellow:#FBBC0C; --blue:#483CFB; --red:#E00613; --turquoise:#00AFA7; } /* Animacion */ .skeleton { background: linear-gradient(to right, #e8e8e8 10%, #fff 50%, #e8e8e8 90%); background-size: 200%; animation: shine 1.5s linear infinite; border-radius: 5px; box-shadow: 0 0 5px rgba(255, 255, 255, 0.3); } @keyframes shine { from { background-position: 200%; } to { background-position: -200%; } } /* estilos del lazyload */ #item-mobile{ width: 58px; height: 58px; } .container-info-modal{ padding: 0rem 0.5rem; } .container-location-mobile, .language-mobile, .currency-responsive{ width: 50px; height: 30px; background-color: #00837D; } .icon-sidebar{ width: 20px; height: 20px; background-color: rebeccapurple; } .word-item-sidebar{ width: 130px; height: 20px; background-color: #00837D; } .link-desktop{ width: 100px; height: 25px; background-color: #00837D; margin: 0rem 0.5rem; } #logo-desktop{ background-color: #00837D; width: 200px; height: 40px; border: none; display: block; } .items-desktop{ width: 110px; height: 40px; background-color: red; margin-right: 10px; } /* FIN estilos del lazyload */ .c-b2b-header__input input, .c-b2b-header__input select { border: 1px solid var(--color-shade-200); color: var(--color-text); background-color: var(--color-white, #ffffff); font-size: var(--font-size-base); height: 42px; border-radius: 0; padding: 12px 42px 8px 12px; font-weight: 400; text-align: left; transition: 0.4s ease-in-out; } .img-icon-club{ width: 10px !important; } .c-b2b-header__nav-products-column { flex: 1 0 20%; } .c-b2b-header__input input:focus-visible, .c-b2b-header__input select:focus-visible { outline: none; border-color: var(--color-secondary); } .c-b2b-header__input input.disabled, .c-b2b-header__input select.disabled { pointer-events: none; opacity: 0.7; } .c-b2b-header__input input, .c-b2b-header__input select { width: 100%; } .c-b2b-header__input .choices { height: 42px; color: var(--color-text); } .c-b2b-header__input .choices:after { content: unset !important; } .c-b2b-header__input .choices.is-open .choices__inner:before { -ms-transform: translate(-4px) rotate(135deg); transform: translate(-4px) rotate(135deg); } .c-b2b-header__input .choices.is-open .choices__inner:after { -ms-transform: translate(4px) rotate(45deg); transform: translate(4px) rotate(45deg); right: 25px; } .c-b2b-header__input .choices__inner { border-radius: 0; } .c-b2b-header__input .choices__inner:after, .c-b2b-header__input .choices__inner:before { content: ""; transition: all 0.25s ease-in-out; position: absolute; background-color: var(--color-text); width: 1px; top: calc(50% - 4px); height: 8px; } .c-b2b-header__input .choices__inner:after { -ms-transform: translate(4px) rotate(135deg); transform: translate(4px) rotate(135deg); right: 25px; } .c-b2b-header__input .choices__inner:before { -ms-transform: translate(-4px) rotate(45deg); transform: translate(-4px) rotate(45deg); right: 12px; } .c-b2b-header__input .choices__inner .choices__item.choices__item--selectable { font-size: var(--font-size-base); } .c-b2b-header__input .choices__list--dropdown .choices__item { font-size: var(--font-size-base) !important; } .c-b2b-header { --color-primary: #ff211c; --color-travelance: #70737A; --color-secondary: #4d1438; --font-family-primary: "Roboto"; font-family: var(--font-family-primary); position: fixed; width: 100%; top: 0; z-index: 2; margin-left: -65px; box-sizing: border-box; } .c-b2b-header *, .c-b2b-header *::after, .c-b2b-header *::before { box-sizing: border-box; } .c-b2b-header a { text-decoration: none; font-weight: 300; } .c-b2b-header__top { padding: 0.6rem 1rem; display: -ms-flexbox; display: flex; -ms-flex-pack: justify; justify-content: space-between; -ms-flex-align: center; align-items: center; height: 58px; position: relative; z-index: 3; background-color: #fff; } .c-b2b-header__top-logo-mobile { width: 200px; height: 40px; } .c-b2b-header__top-nav-item { display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; height: 40px; color: #000; font-size: 14px; letter-spacing: 0; padding: 0 30px; cursor: pointer; transition: 0.3s all; } /* .c-b2b-header__top-nav-item:hover { color: #C6C6C6; transition: 0.3s all; } */ .c-b2b-header__top-nav { -ms-flex: 1 1 auto; flex: 1 1 auto; display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; -ms-flex-pack: center; justify-content:flex-end; } .c-b2b-header__top-nav.is-active .c-b2b-header__top-nav-item { opacity: 0; width: 0; height: 0; pointer-events: none; padding: 0; } #btn-currency-mobile{ width: 50px !important; border-radius: 0px!important; } #btn-currency-mobile p{ margin-left: 0.5rem; font-size: 15px; } #btn-currency-mobile span{ font-size: 15px; } .c-b2b-header__top-nav.is-active .c-b2b-header__top-nav-search { transition: opacity 0.6s; } .c-b2b-header__top-nav:not(.is-active) .c-b2b-header__top-nav-search { opacity: 0; width: 0; height: 0; pointer-events: none; } .bg-modal ul li a::after { content: ""; border-style: solid; border-width: 1px 1px 0 0; display: inline-block; height: 6px; -ms-transform: rotate(45deg) translateY(-50%); transform: rotate(45deg) translateY(-50%); top: 50%; width: 6px; position: absolute; right: 10px; } .bg-modal ul li a::before { content: ""; position: absolute; top: 0; left: 0px; width: calc(100% + 20px); height: 100%; background-color: rgba(222, 223, 224, 0.56); transition: 0.4s all; opacity: 0; z-index: -1; } .c-b2b-header__top-left a{ width: 45px; color: #fff; } .c-b2b-header__sidebar-options .c-b2b-header__sidebar-menu-section-list{ border: none !important; } .c-b2b-header__top-right { display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; gap: 20px; -ms-flex-pack: end; justify-content: flex-end; } .c-b2b-header__location-container { position: relative; display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; cursor: pointer; gap: 10px; } .c-b2b-header__location-selected { width: 75px; height: 40px; display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; gap: 6px; font-size: 16px; font-weight: 300; color: #1e1e1e; } .c-b2b-header__location-selected img, .c-b2b-header__location-selected svg { -ms-flex-negative: 0; flex-shrink: 0; width: 13px; } .c-b2b-header__location-selection { top: 100%; position: absolute; right: 0; padding: 24px; z-index: 2; background: #FFFFFF 0% 0% no-repeat padding-box; background-color: var(--color-white, #ffffff); box-shadow: 0 1px 3px rgba(0, 0, 0, .12), 0 1px 2px rgba(0, 0, 0, .24); width: 688px; max-width: 90vw; transition: 0.4s all; } .c-b2b-header__location-selection:not(.is-active) { opacity: 0; pointer-events: none; } .c-b2b-header__location-selection-title { font-size: 14px; letter-spacing: 0; font-weight: 500; color: #232832; } .c-b2b-header__location-selection-list { margin-top: 16px; display: grid; list-style: none; margin-bottom: 0; grid-template-columns: 1fr 1fr; font-size: 14px; letter-spacing: 0; color: #232832; padding: 0; } .c-b2b-header__location-selection-list a { display: block; padding: 7px; position: relative; z-index: 1; color: #232832; } /* .c-b2b-header__location-selection-list a:after { content: ""; position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: -1; background-color: var(--color-secondary); opacity: 0; transition: 0.4s all; } */ /* .c-b2b-header__location-selection-list a.is-active:before { content: ""; display: inline-block; -ms-transform: rotate(45deg); transform: rotate(45deg); height: 13px; width: 6px; border-bottom: 1px solid var(--color-secondary); border-right: 1px solid var(--color-secondary); position: absolute; right: 14px; } */ .c-b2b-header__market-container { position: relative; display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; cursor: pointer; } .c-b2b-header__market-selected { width: 30px; height: 30px; border-radius: 50%; overflow: hidden; background-color: rgba(255, 255, 255, 0.16); display: -ms-flexbox; display: flex; -ms-flex-pack: center; justify-content: center; -ms-flex-align: center; align-items: center; padding: 7px; } .c-b2b-header__market-selected img, .c-b2b-header__market-selected svg { border-radius: 50%; overflow: hidden; width: 100%; height: 100%; object-fit: cover; } .c-b2b-header__market-selection { top: 100%; position: absolute; right: 0; padding: 24px; z-index: 2; background: #FFFFFF 0% 0% no-repeat padding-box; background-color: var(--color-white, #ffffff); box-shadow: 0 1px 3px rgba(0, 0, 0, .12), 0 1px 2px rgba(0, 0, 0, .24); width: 260px; max-width: 100vw; transition: 0.4s all; } .c-b2b-header__market-selection:not(.is-active) { opacity: 0; pointer-events: none; z-index: -1; } .c-b2b-header__market-selection-title { font-size: 14px; letter-spacing: 0; font-weight: 500; color: #232832; } .c-b2b-header__market-selection-list { margin-top: 16px; margin-bottom: 0; list-style: none; font-size: 14px; letter-spacing: 0; color: #232832; padding: 0; } .c-b2b-header__market-selection-list a { padding: 7px; position: relative; display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; gap: 10px; color: #232832; } .c-b2b-header__market-selection-list a:after { content: ""; position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: -1; background-color: var(--color-secondary); opacity: 0; transition: 0.4s all; } .c-b2b-header__market-selection-list a.is-active:before { content: ""; display: inline-block; -ms-transform: rotate(45deg); transform: rotate(45deg); height: 13px; width: 6px; border-bottom: 1px solid var(--color-secondary); border-right: 1px solid var(--color-secondary); position: absolute; right: 14px; } .c-b2b-header__market-selection-icon { display: -ms-flexbox; display: flex; } .c-b2b-header__market-selection-icon img, .c-b2b-header__market-selection-icon svg { width: 18px; height: 18px; overflow: hidden; border-radius: 50%; object-fit: cover; } .c-b2b-header__currency-container { position: relative; display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; height: 40px; cursor: pointer; } .c-b2b-header__currency-selected { width: 30px; height: 30px; border-radius: 50%; overflow: hidden; background-color: transparent; display: -ms-flexbox; display: flex; -ms-flex-pack: center; justify-content: center; -ms-flex-align: center; align-items: center; padding: 7px; color:#1e1e1e; font-weight: 500; font-size: 20px; } .c-b2b-header__currency-selection { top: 100%; position: absolute; right: 0; padding: 24px; z-index: 2; background: #FFFFFF 0% 0% no-repeat padding-box; background-color: var(--color-white, #ffffff); box-shadow: 0 1px 3px rgba(0, 0, 0, .12), 0 1px 2px rgba(0, 0, 0, .24); width: 260px; max-width: 100vw; transition: 0.4s all; } .c-b2b-header__currency-selection:not(.is-active) { opacity: 0; pointer-events: none; z-index: -1; } .c-b2b-header__currency-selection-title { font-size: 14px; letter-spacing: 0; font-weight: 500; color: #232832; } .c-b2b-header__currency-selection-list { /* margin-top: 16px; */ margin-bottom: 0; list-style: none; font-size: 14px; letter-spacing: 0; color: #232832; padding: 0; } .c-b2b-header__currency-selection-list a { padding: 7px; position: relative; display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; gap: 10px; color: #232832; } .c-b2b-header__currency-selection-list a:after { content: ""; position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: -1; background-color: var(--color-secondary); opacity: 0; transition: 0.4s all; } .c-b2b-header__currency-selection-list a.is-active:before { content: ""; display: inline-block; -ms-transform: rotate(45deg); transform: rotate(45deg); height: 13px; width: 6px; border-bottom: 1px solid var(--color-secondary); border-right: 1px solid var(--color-secondary); position: absolute; right: 14px; } .c-b2b-header__currency-selection-icon { font-weight: 500; } .c-b2b-header__user-container { display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; gap: 12px; color:#000; cursor: pointer; position: relative; } .c-b2b-header__user-mb { width: 58px; height: 40px; display: -ms-inline-flexbox; display: flex; -ms-flex-pack: center; justify-content: center; -ms-flex-align: center; align-items: center; } .c-b2b-header__user-mb svg path{ fill: var(--color-primary); } .c-b2b-header__user-mb img{ width: 60%; vertical-align: middle; } @media (min-width:770px) and (max-width:1200px){ .c-b2b-header__user-mb img{ width: 29px; height: 29px; vertical-align: middle; } } .c-b2b-header__user-mb svg { width:29px; height: 29px; object-fit: contain; fill: currentColor; -ms-flex-negative: 0; flex-shrink: 0; } .c-b2b-header__user-image { width: 32px; height: 32px; border-radius: 50%; display: -ms-inline-flexbox; display: inline-flex; -ms-flex-pack: center; justify-content: center; -ms-flex-align: center; align-items: center; border-radius: 50%; } .c-b2b-header__user-image img, .c-b2b-header__user-image svg { width: 29px; height: 29px; border-radius: 50%; object-fit: contain; fill: currentColor; -ms-flex-negative: 0; flex-shrink: 0; } .c-b2b-header__user-company { width: 250px; height: 20px; font-size: 14px; font-weight: 400; } .c-b2b-header__user-name { width: 230px; margin-top: 0.2rem; height: 20px; font-size: 12px; font-weight: 300; } .c-b2b-header__user-modal-container { width: 380px; background-color: var(--color-white, #ffffff); position: absolute; top: 0; right: 0; height: 100%; overflow-y: auto; } .c-b2b-header__user-modal { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 4; background: rgba(0, 0, 0, 0.12); transition: transform 1s, background-color 1s ease 0.8s; } .c-b2b-header__user-modal:not(.is-active) { -ms-transform: translateX(100%); transform: translateX(100%); background: transparent; transition: transform 1s ease 0.3s, background-color 0.3s ease; } .c-b2b-header__user-modal-profile { padding: 0.5rem 1rem; /* background-color: #EFF0F1; */ display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; flex-direction: column; gap: 20px; } .c-b2b-header__user-modal-icon { border: 1px solid #DEDFE0; background-color: #FFFFFF; display: -ms-flexbox; display: flex; -ms-flex-pack: center; justify-content: center; -ms-flex-align: center; align-items: center; border-radius: 50%; width: 100px; height: 100px; -ms-flex-negative: 0; flex-shrink: 0; } .c-b2b-header__user-modal-icon img { width: 100px; height: 100px; border-radius: 50%; } .c-b2b-header__user-modal-company { width: 100%; height: 30px; background-color: red; font-size: 1.1rem; font-weight: 500; color: #000; margin-bottom: 2px; } .c-b2b-header__user-modal-name { width: 200px; height: 20px; font-size: 14px; font-weight: 500; color: #000; line-height: 1.4em; text-align: center; margin: 0.5rem auto; } .c-b2b-header__user-modal-email { width: 150px; height: 20px; font-size: 14px; font-weight: 300; color: #000; line-height: 1.4em; text-align: center; margin: 0.5rem auto; } .c-b2b-header__user-modal-edit { font-size: 12px; color: var(--color-secondary); font-weight: 500; margin-top: 8px; display: inline-block; } .c-b2b-header__user-modal-options { padding: 10px 24px; } .c-b2b-header__input { -ms-flex: 1; flex: 1; } .c-b2b-header__input .choices__inner { background-color: var(--color-white, #ffffff); min-height: inherit; } .c-b2b-header__user-modal-title { width: 150px; height: 20px; background-color: red; font-size: 0.9rem !important; line-height: 1.4em; color: #70737A; font-weight: 500; margin-bottom: 0.8rem; margin-top: 1rem; text-transform: uppercase; letter-spacing: 0.5px; padding: 0.6rem; } .c-b2b-header__user-modal-select { margin-bottom: 24px; } .c-b2b-header__user-modal-config { border-top: 1px solid #DEDFE0; border-bottom: 1px solid #DEDFE0; padding-top: 18px; padding-bottom: 18px; background-color: #fff; } .c-b2b-header__user-modal-config-links { font-size: 14px; font-weight: 300; list-style: none; padding: 0; margin: 0; } .c-b2b-header__user-modal-bottom { width: 70%; height: 40px; margin: 1rem auto; display: -ms-flexbox; display: flex; -ms-flex-pack: center; justify-content: center; align-items: center; } .c-b2b-header__user-modal-btn { width: 100%; background: var(--color-primary); display: flex; align-items: center; justify-content: center; padding: 12px; font-size:1rem; color: #fff; font-weight: 500; text-align: center; } .c-b2b-header__user-modal-btn svg{ width: 20px; height: 20px; vertical-align: middle; fill: #fff; margin-right: 0.5rem; } .c-b2b-header__nav-products { display: -ms-flexbox; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap; background-color: var(--color-white, #ffffff); z-index: 1; gap: 20px; max-width: 100%; margin-top: 30px; } .c-b2b-header__nav-products-list { margin-top: 10px; border-top: 1px solid #DEDFE0; padding-top: 14px; column-gap: 64px; } .c-b2b-header__nav-products-list.one-column { min-width: 230px; column-count: 1; } .c-b2b-header__nav-products-item { margin-bottom: 20px; break-inside: avoid; } .c-b2b-header__nav-products-title { font-size: 16px; line-height: 1.25em; font-weight: 500; color: #DF271C; text-transform: uppercase; } .c-b2b-header__nav-products-title.gray { color: #70737A; } .c-b2b-header__nav-products-subtitle { font-size: 14px; font-weight: 500; line-height: 1.4em; color: #232832; margin-top: 8px; } .c-b2b-header__nav-products-link { list-style: none; padding: 0; } .c-b2b-header__nav-products-link a { font-size: 14px; line-height: 1.8em; color: #232832; display: -ms-flexbox; display: flex; -ms-flex-pack: justify; justify-content: space-between; transition: 0.4s all; } .c-b2b-header__nav-products-logo { width: 110px; height: 28px; object-position: left; object-fit: contain; } .c-b2b-header__nav-products-count { background-color: var(--color-secondary); color: var(--color-white, #ffffff); border-radius: 22px; font-weight: 500; font-size: 14px; min-width: 22px; height: 22px; display: -ms-flexbox; display: flex; -ms-flex-pack: center; justify-content: center; -ms-flex-align: center; align-items: center; padding: 2px 6px; } .c-b2b-header__top-nav-search { width: 320px; position: relative; max-width: 100%; } .c-b2b-header__top-nav-search input { height: 42px; width: 100%; border-radius: 50px; background-color: var(--color-white, #ffffff); border: none; padding-left: 44px; font-size: 14px; color: #70737A; font-family: var(--font-family-primary); } .c-b2b-header__top-nav-search input::-webkit-input-placeholder { font-size: 14px; color: #70737A; font-family: var(--font-family-primary); font-weight: 300; } .c-b2b-header__top-nav-search input:-ms-input-placeholder { font-size: 14px; color: #70737A; font-family: var(--font-family-primary); font-weight: 300; } .c-b2b-header__top-nav-search input::placeholder { font-size: 14px; color: #70737A; font-family: var(--font-family-primary); font-weight: 300; } .c-b2b-header__top-nav-search input:focus-visible { outline: none; } .c-b2b-header__top-nav-search-close { position: absolute; left: 20px; top: 50%; display: -ms-flexbox; display: flex; -ms-transform: translateY(-50%); transform: translateY(-50%); } .c-b2b-header__top-nav-search-submit { border-radius: 50%; width: 38px; height: 38px; top: 2px; right: 2px; background-color: var(--color-secondary); border: none; position: absolute; display: -ms-flexbox; display: flex; -ms-flex-pack: center; justify-content: center; -ms-flex-align: center; align-items: center; } .c-b2b-header__top-nav-search-submit svg { width: 16px; height: 16px; object-fit: contain; fill: var(--color-white, #ffffff); } .c-b2b-header__nav { display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; height: 30px; background:#4d1438; padding: 12px 23px; width: 100%; } .c-b2b-header__nav-logo { width: 200px; -ms-flex-negative: 0; flex-shrink: 0; } .c-b2b-header__nav-logo img { max-height: 29px; object-position: left; object-fit: contain; } .c-b2b-header__nav-menu { width: 100%; display: -ms-flexbox; display: flex; list-style: none; -ms-flex-pack: center; justify-content: center; margin: 0; overflow-x: auto; scrollbar-width: thin; /* "auto" or "thin" */ scrollbar-color: var(--color-travelance) var(--color-white, #ffffff); /* scroll thumb and track */ cursor: initial; } .c-b2b-header__nav-menu::-webkit-scrollbar { width: 4px; height: 2px; } .c-b2b-header__nav-menu::-webkit-scrollbar-track { background: #dedfe0; /* color of the tracking area */ } .c-b2b-header__nav-menu::-webkit-scrollbar-thumb { background-color: var(--color-travelance); /* color of the scroll thumb */ border-radius: 2px; /* roundness of the scroll thumb */ border: 0; } .c-b2b-header__nav-menu a { font-size: 14px; color: #fff; position: relative; display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; /* height: 30px; */ padding: 0 12px; transition: 0.4s all; white-space: nowrap; } .c-b2b-header__sidebar { position: fixed; left: -64px; top: 60px; width: 64px; height: calc(100% - 58px); box-shadow: 1px 0px 0px #DEDFE0; background-color: var(--color-white, #ffffff); padding: 16px 12px; display: flex; flex-direction: column; transition: width 0.5s; z-index: 2; } .c-b2b-header.sidebar-open .c-b2b-header__sidebar { left: 0; } @media (min-width: 770px) { .title-gest{ display: none; } .c-b2b-header__sidebar { left: 0; } .travelance-shape{ display: none; } } .c-b2b-header__sidebar img, .c-b2b-header__sidebar svg { width: 16px; -ms-flex-negative: 0; flex-shrink: 0; } .c-b2b-header__sidebar-link { display: flex; -ms-flex-align: center; align-items: center; gap: 22px; padding: 10px 10px; transition: 0.4s all; color: #70737A; /* width: 58px; height: 58px; */ } .c-b2b-header__sidebar-link .menu-word { font-size: 0.9rem !important; line-height: 1.4em; color: #70737A; font-weight: 500; text-transform: uppercase; letter-spacing: 0.5px; } .c-b2b-header:not(.sidebar-open) .c-b2b-header__sidebar-link .menu-word { width: 0; opacity: 0; } .c-b2b-header:not(.sidebar-open) .container-menu-sidebar { width: 0; opacity: 0; } .c-b2b-header__sidebar-logo { color: #000; } .c-b2b-header__sidebar-logo-mini { width: 20px; } .link-sidebar-submenu{ position: relative; display: flex; flex-direction: row; align-items: center; gap: 10px; } .c-b2b-header__sidebar-logo-full { position: relative; display: flex; flex-direction: row; align-items: center; gap: 10px; padding: 1rem 0.6rem; transition: transform 0.3s ease, all 0.4s ease; } .c-b2b-header__sidebar-logo-full:not(:last-child){ border-bottom: 0.3px solid rgb(197, 197, 197); } .c-b2b-header__sidebar-logo-full img { width: auto !important; max-width: 75px; } .c-b2b-header__sidebar-logo-full:not(.link-sidebar):after { content: ""; border-style: solid; border-width: 1px 1px 0 0; display: inline-block; height: 6px; right: 15px; -ms-transform: rotate(45deg) translateY(-50%); transform: rotate(45deg) translateY(-50%); position: absolute; top: 50%; width: 6px; } .c-b2b-header.is-stuck .c-b2b-header__nav { display: none; } .c-b2b-header.is-stuck .c-b2b-header__sidebar, .c-b2b-header.is-stuck .c-b2b-header__sidebar-contact, .c-b2b-header.is-stuck .c-b2b-header__sidebar-nav { top: 58px; height: calc(100% - 58px); } .c-b2b-header__sidebar-menu { position: fixed; left: 211px; top: 58px; width: 280px; height: calc(100% - 58px); box-shadow: 1px 0px 0px #DEDFE0; background-color: var(--color-white, #ffffff); padding: 18px 16px; overflow-y: auto; scrollbar-width: thin; /* "auto" or "thin" */ scrollbar-color: #ededed var(--color-white, #ffffff); /* scroll thumb and track */ transition: 0.6s all; -ms-transform: translateX(0); transform: translateX(0); } .c-b2b-header__sidebar-options { position: fixed; left: 130px; top: 60px; width: 280px; height: calc(100% - 58px); box-shadow: 1px 0px 0px #DEDFE0; background-color: var(--color-white, #ffffff); padding: 18px 16px; overflow-y: auto; scrollbar-width: thin; transition: 0.6s all; -ms-transform: translateX(0); transform: translateX(0); } .c-b2b-header__sidebar-options::-webkit-scrollbar { width: 7px; } .c-b2b-header__sidebar-options::-webkit-scrollbar-track { background: #ededed; } .c-b2b-header__sidebar-options::-webkit-scrollbar-thumb { background-color: var(--color-travelance); border-radius: 2px; border: 2px solid #ededed; } .c-b2b-header__sidebar-options:not(.is-active) { -ms-transform: translateX(-100%) translateX(-210px); transform: translateX(-100%) translateX(-210px); } .c-b2b-header__sidebar-menu::-webkit-scrollbar { width: 7px; } .c-b2b-header__sidebar-menu::-webkit-scrollbar-track { background: #ededed; /* color of the tracking area */ } .c-b2b-header__sidebar-menu::-webkit-scrollbar-thumb { background-color: var(--color-travelance); /* color of the scroll thumb */ border-radius: 2px; /* roundness of the scroll thumb */ border: 2px solid #ededed; } .c-b2b-header__sidebar-menu:not(.is-active) { -ms-transform: translateX(-100%) translateX(-210px); transform: translateX(-100%) translateX(-210px); } .c-b2b-header__sidebar-menu-title { font-size: 14px; font-weight: 500; color: #232832; text-transform: uppercase; } .c-b2b-header__sidebar-menu-section-list { margin-top: 9px; list-style: none; font-size: 14px; font-weight: 300; padding: 0; margin-bottom: 18px; padding-bottom: 21px; border-bottom: 1px solid rgba(112, 115, 122, 0.2); } .c-b2b-header__sidebar-menu-section-list a { display: block; padding: 9px 0; color: #232832; position: relative; transition: 0.4s all; } .c-b2b-header__sidebar-menu-section-list a:before { content: ""; position: absolute; top: 0; left: -10px; width: calc(100% + 20px); height: 100%; background-color: rgba(222, 223, 224, 0.56); transition: 0.4s all; opacity: 0; z-index: -1; } .c-b2b-header__sidebar-menu-section-list a:after { content: ""; border-color: #70737A; border-style: solid; border-width: 1px 1px 0 0; display: inline-block; height: 6px; -ms-transform: rotate(45deg) translateY(-50%); transform: rotate(45deg) translateY(-50%); top: 46%; width: 6px; position: absolute; right: 4px; } .c-b2b-header__sidebar-menu { position: fixed; left: 211px; top: 60px; width: 280px; height: calc(100% - 58px); box-shadow: 1px 0px 0px #DEDFE0; background-color: var(--color-white, #ffffff); padding: 18px 16px; overflow-y: auto; scrollbar-width: thin; /* "auto" or "thin" */ scrollbar-color: #ededed var(--color-white, #ffffff); /* scroll thumb and track */ transition: 0.6s all; -ms-transform: translateX(0); transform: translateX(0); } .c-b2b-header__sidebar-menu::-webkit-scrollbar { width: 7px; } .c-b2b-header__sidebar-menu::-webkit-scrollbar-track { background: #ededed; /* color of the tracking area */ } .c-b2b-header__sidebar-menu::-webkit-scrollbar-thumb { background-color: var(--color-travelance); /* color of the scroll thumb */ border-radius: 2px; /* roundness of the scroll thumb */ border: 2px solid #ededed; } .c-b2b-header__sidebar-menu:not(.is-active) { -ms-transform: translateX(-100%) translateX(-210px); transform: translateX(-100%) translateX(-210px); } .c-b2b-header__sidebar-menu-title { font-size: 14px; font-weight: 500; color: #232832; text-transform: uppercase; } .c-b2b-header__sidebar-menu-section-list { margin-top: 9px; list-style: none; font-size: 14px; font-weight: 300; padding: 0; margin-bottom: 18px; padding-bottom: 21px; border-bottom: 1px solid rgba(112, 115, 122, 0.2); } .c-b2b-header__sidebar-menu-section-list a { display: block; padding: 9px 0; color: #232832; position: relative; } .c-b2b-header__sidebar-menu-section-list a:after { content: ""; border-color: #70737A; border-style: solid; border-width: 1px 1px 0 0; display: inline-block; height: 6px; -ms-transform: rotate(45deg) translateY(-50%); transform: rotate(45deg) translateY(-50%); top: 46%; width: 6px; position: absolute; right: 4px; } .c-b2b-header__sidebar-nav { position: fixed; left: 211px; top: 60px; width: 280px; height: calc(100% - 58px); box-shadow: 1px 0px 0px #DEDFE0; background-color: var(--color-white, #ffffff); padding: 18px 16px; overflow-y: auto; scrollbar-width: thin; /* "auto" or "thin" */ scrollbar-color: #ededed var(--color-white, #ffffff); /* scroll thumb and track */ transition: 0.6s all; -ms-transform: translateX(0); transform: translateX(0); } .c-b2b-header__sidebar-nav::-webkit-scrollbar { width: 7px; } .c-b2b-header__sidebar-nav::-webkit-scrollbar-track { background: #ededed; /* color of the tracking area */ } .c-b2b-header__sidebar-nav::-webkit-scrollbar-thumb { background-color: var(--color-travelance); /* color of the scroll thumb */ border-radius: 2px; /* roundness of the scroll thumb */ border: 2px solid #ededed; } .c-b2b-header__sidebar-nav:not(.is-active) { -ms-transform: translateX(-100%) translateX(-210px); transform: translateX(-100%) translateX(-210px); } .c-b2b-header__sidebar-nav-title { font-size: 14px; font-weight: 500; color: #232832; text-transform: uppercase; } .c-b2b-header__sidebar-nav-section-list { margin-top: 9px; list-style: none; font-size: 14px; font-weight: 300; padding: 0; margin-bottom: 18px; padding-bottom: 21px; } .c-b2b-header__sidebar-nav-section-list a { display: block; padding: 9px 0; color: #232832; position: relative; transition: 0.4s all; } .c-b2b-header__sidebar-nav-section-list a:before { content: ""; position: absolute; top: 0; left: -10px; width: calc(100% + 20px); height: 100%; background-color: rgba(222, 223, 224, 0.56); transition: 0.4s all; opacity: 0; z-index: -1; } .c-b2b-header__sidebar-nav-section-list a:after { content: ""; border-color: #70737A; border-style: solid; border-width: 1px 1px 0 0; display: inline-block; height: 6px; -ms-transform: rotate(45deg) translateY(-50%); transform: rotate(45deg) translateY(-50%); top: 46%; width: 6px; position: absolute; right: 4px; } .options-bar-mobile{ display: flex; flex-direction: column; align-items: flex-start; } .options-bar-mobile button, .options-bar-mobile a{ width: 100%; height: 50px; border: none; font-size: 14px; text-align: left; color: #000; display: flex; align-items: center; } .options-bar-mobile button a{ color: var(--color-travelance); } .c-b2b-header__sidebar-nav-section-list:not(:last-of-type) a { border-bottom: 1px solid rgba(112, 115, 122, 0.2); } .c-b2b-header__sidebar-contact { position: fixed; left: 211px; top: 60px; width: 280px; height: calc(100% - 58px); box-shadow: 1px 0px 0px #DEDFE0; background-color: var(--color-white, #ffffff); padding: 18px 16px; overflow-y: auto; scrollbar-width: thin; /* "auto" or "thin" */ scrollbar-color: #ededed var(--color-white, #ffffff); /* scroll thumb and track */ transition: 0.6s all; -ms-transform: translateX(0); transform: translateX(0); } .c-b2b-header__sidebar-contact::-webkit-scrollbar { width: 7px; } .c-b2b-header__sidebar-contact::-webkit-scrollbar-track { background: #ededed; /* color of the tracking area */ } .c-b2b-header__sidebar-contact::-webkit-scrollbar-thumb { background-color: var(--color-travelance); /* color of the scroll thumb */ border-radius: 2px; /* roundness of the scroll thumb */ border: 2px solid #ededed; } .c-b2b-header__sidebar-contact:not(.is-active) { -ms-transform: translateX(-100%) translateX(-210px); transform: translateX(-100%) translateX(-210px); } .c-b2b-header__sidebar-contact-title { font-size: 14px; font-weight: 500; color: #232832; text-transform: uppercase; } .c-b2b-header__sidebar-contact-subtitle { font-size: 20px; font-weight: 400; color: #232832; margin-top: 16px; } .c-b2b-header__sidebar-contact-description { font-size: 14px; font-weight: 300; color: #232832; margin-top: 6px; line-height: 1.4em; } .c-b2b-header__sidebar-contact-description b { font-weight: 500; } .c-b2b-header__sidebar-contact-description a { color: inherit; font-weight: 500; } .c-b2b-header:not(.sidebar-open) .c-b2b-header__sidebar-logo-full { display: none; } .c-b2b-header:not(.sidebar-open) .link-sidebar-submenu{ display: none; } .c-b2b-header:not(.sidebar-open) .submenu-item{ display: none; } .c-b2b-header:not(.sidebar-open) .c-b2b-header__sidebar-menu, .c-b2b-header:not(.sidebar-open) .c-b2b-header__sidebar-nav, .c-b2b-header:not(.sidebar-open) .c-b2b-header__sidebar-contact { left: 64px; } .c-b2b-header.sidebar-open .c-b2b-header__sidebar { width: 250px; } .c-b2b-header.sidebar-open .c-b2b-header__sidebar-logo-mini { display: none; } .c-b2b-header__club { display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; cursor: pointer; position: relative; } .c-b2b-header__club-badge { --bronze: #FCC71E !important; --gold: #FBBC0C; --silver: #C6C6C6; --initial: #E00613; width: 30px; height: 30px; border-radius: 100%; display: -ms-flexbox; display: flex; -ms-flex-pack: center; justify-content: center; -ms-flex-align: center; align-items: center; background-color: transparent; -ms-flex-negative: 0; flex-shrink: 0; margin-right: 0.7rem; } .c-b2b-header__club-badge img, .c-b2b-header__club-badge svg { width: 18px; height: 21px; object-fit: contain; margin-left: 2px; } .c-b2b-header__club-info { width: 110px; height: 40px; font-size: 14px; font-weight: 300; line-height: 1.166em; color:#000; display: flex; align-items: center; justify-content: space-between; } .c-b2b-header__club-info span svg{ width: 20px; height: 20px; vertical-align: middle; fill: #9a9a9a; margin-left: 2px; } .c-b2b-header__club-expand { position: absolute; background-color: var(--color-white, #ffffff); top: calc(100% + 20px); width: 300px; height: auto; padding: 0.4rem 0.8rem; left: 50%; -ms-transform: translateX(-50%); transform: translateX(-50%); transition: 0.4s all; background-color: var(--color-white, #ffffff); box-shadow: 0 1px 3px rgba(0, 0, 0, .12), 0 1px 2px rgba(0, 0, 0, .24); } .c-b2b-header__club-expand:not(.is-active) { opacity: 0; pointer-events: none; } .c-b2b-header__club-expand:after { content: ""; position: absolute; left: 50%; -ms-transform: translateX(-50%); transform: translateX(-50%); top: -14px; border: 16px solid transparent; border-top: 0; border-bottom: 16px solid var(--color-white, #ffffff); z-index: -1; } .c-b2b-header__club-progress { margin-top: 39px; margin-bottom: 32px; display: -ms-flexbox; display: flex; border-radius: var(--border-radius, 10px); height: 17px; background-color: var(--color-text-100, #E9E9EA); position: relative; } .c-b2b-header__club-progress-bar { position: relative; -ms-flex: 1; flex: 1; } .c-b2b-header__club-progress-bar:first-of-type .c-b2b-header__club-progress-info { border-top-left-radius: var(--border-radius, 10px); border-bottom-left-radius: var(--border-radius, 10px); } .c-b2b-header__club-progress-bar:last-child .c-b2b-header__club-progress-info { border-top-right-radius: var(--border-radius, 10px); border-bottom-right-radius: var(--border-radius, 10px); } .c-b2b-header__club-progress-bar:not(:last-child):after { content: ""; position: absolute; height: 29px; width: 1px; right: 0; background-color: var(--color-text-300, #A7A9AA); top: -6px; } .c-b2b-header__club-progress-bar:not(.is-active) .c-b2b-header__club-progress-info { display: none; } .c-b2b-header__club-progress-bar.bronze .c-b2b-header__club-progress-name { background: linear-gradient(180deg, #805A36 0%, #C2A780 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; text-fill-color: transparent; } .c-b2b-header__club-progress-bar.bronze .c-b2b-header__club-progress-info { background: #CC7E3D; } .c-b2b-header__club-progress-bar.bronze .c-b2b-header__club-progress-info:after { background-color: #CC7E3D; } .c-b2b-header__club-progress-bar.bronze .c-b2b-header__club-progress-info-number { background-color: #CC7E3D; } .c-b2b-header__club-progress-bar.bronze .c-b2b-header__club-progress-info-number:after { border-top: 7px solid #CC7E3D; } .c-b2b-header__club-progress-bar.silver .c-b2b-header__club-progress-name { background: linear-gradient(180deg, #828486 0%, #DBDBDB 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; text-fill-color: transparent; } .c-b2b-header__club-progress-bar.silver .c-b2b-header__club-progress-info { background: #B6B6B6; } .c-b2b-header__club-progress-bar.silver .c-b2b-header__club-progress-info:after { background-color: #B6B6B6; } .c-b2b-header__club-progress-bar.silver .c-b2b-header__club-progress-info-number { background-color: #B6B6B6; } .c-b2b-header__club-progress-bar.silver .c-b2b-header__club-progress-info-number:after { border-top: 7px solid #B6B6B6; } .c-b2b-header__club-progress-bar.gold .c-b2b-header__club-progress-name { background: linear-gradient(180deg, #D89A11 0%, #D8D485 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; text-fill-color: transparent; } .c-b2b-header__club-progress-bar.gold .c-b2b-header__club-progress-info { background: #E7C827; } .c-b2b-header__club-progress-bar.gold .c-b2b-header__club-progress-info:after { background-color: #E7C827; } .c-b2b-header__club-progress-bar.gold .c-b2b-header__club-progress-info-number { background-color: #E7C827; } .c-b2b-header__club-progress-bar.gold .c-b2b-header__club-progress-info-number:after { border-top: 7px solid #E7C827; } .c-b2b-header__club-progress-name { font-size: 14px; font-weight: 600; position: absolute; left: 50%; -ms-transform: translateX(-50%); transform: translateX(-50%); top: calc(100% + 15px); } .c-b2b-header__club-progress-info { height: 17px; width: 60%; background: #CC7E3D; position: relative; z-index: 1; } .c-b2b-header__club-progress-info-badge { position: absolute; top: 50%; -ms-transform: translateY(-50%); transform: translateY(-50%); right: -13px; filter: drop-shadow(0px 0px 10px rgba(0, 0, 0, 0.35)); width: 26px; max-width: inherit; } .c-b2b-header__club-progress-info-number { font-weight: 600; font-size: 14px; color: white; background-color: #CC7E3D; position: absolute; top: -42px; padding: 4px 7px; border-radius: 8px; line-height: 1.3em; left: calc(100% - 40px); width: 80px; text-align: center; } .c-b2b-header__club-progress-info-number:after { content: ""; position: absolute; left: 50%; -ms-transform: translateX(-50%); transform: translateX(-50%); bottom: -7px; border: 7px solid transparent; border-bottom: 0; border-top: 7px solid #CC7E3D; z-index: -1; } .has-b2b-header { margin: 0; padding-left: 65px; } .c-b2b-header__user-modal-config-links li a { display: block; color: #232832; padding: 9px 0; position: relative; z-index: 1; transition: 0.4s all; } .c-b2b-header__user-modal-config-links li a:before { content: ""; position: absolute; top: 0; left: -10px; width: calc(100% + 20px); height: 100%; background-color: rgba(222, 223, 224, 0.56); transition: 0.4s all; opacity: 0; z-index: -1; } .c-b2b-header__user-modal-config-links li a:after { content: ""; border-style: solid; border-width: 1px 1px 0 0; display: inline-block; height: 6px; -ms-transform: rotate(45deg) translateY(-50%); transform: rotate(45deg) translateY(-50%); top: 50%; width: 6px; position: absolute; right: 4px; border-color: #000 !important; } .link-active{ background-color: rgba(222, 223, 224, 0.56); } .level-club-sidebar{ font-weight: bold; } .num-club-header{ font-weight: 300; } .title-club-header{ font-size: 14px; } .line-header{ width: 1px; height: 25px; background-color: #cccccc; } .icon-header svg{ width: 18px; height: 18px; vertical-align: middle; margin-right: 5px; fill: #70737A; } .icon-header svg line{ stroke: #70737A; } .icon-more-product svg{ width: 20px; height: 20px; vertical-align: middle; fill: #fff; } .icon-more-product-header svg{ width: 20px; height: 20px; vertical-align: middle; fill: #9a9a9a; margin-left: -5px; } .link-more-product{ /* height: 30px; */ display: flex; align-items: center; justify-content: center; padding: 0 16px; cursor: pointer; } .link-more-product a{ padding: 0px !important; } .title-club-sidebar h5{ margin: 5px 5px 0px 0px !important; font-weight: 400; } .title-club-sidebar{ display: flex; align-items: center; justify-content: space-between; margin: 0px !important; } .title-club-sidebar-header{ display: flex; align-items: center; justify-content: flex-start; margin: 0px !important; } .title-club-sidebar-header h5{ margin: 20px 5px 0px 0px !important; font-weight: 400; } /* .submenu-club{ padding: 0.8rem; } */ .c-b2b-header__sidebar-logo-full:not(.link-sidebar).rotated::after { -ms-transform: rotate(90deg) translateY(-50%);  transform: rotate(135deg) translateY(-50%); } .submenu-sidebar { max-height: 0; overflow: hidden; transition: max-height 0.3s ease-in-out; } .submenu-sidebar.active { max-height: 300px;  } .link-sidebar-submenu{ background-color: #f7f7f7; padding: 0.6rem 0rem 0.6rem 3rem; } .container-items-sidebar{ width: 100%; /* padding: 0.6rem; */ color: #000 !important; border-bottom: 0.3px solid rgb(197, 197, 197); } .link-sidebar-submenu{ color: #70737A; } .link-sidebar-submenu:not(:last-of-type){ border-bottom: 0.3px solid rgb(197, 197, 197); } .icon-sidebar svg{ width: 20px; height: 20px; fill: #70737A !important; vertical-align: middle; } .c-b2b-header__top-left a img { width: 150px; } /* Hamburguesa menu */ .bars-menu{ display: none; width: 30px; height: 30px; cursor: pointer; position: relative; z-index: 1000; margin-top: 12px; margin-left: 10px; } .bars-menu span{ width: 100%; height: 2px; display: block; background: #ff211c; margin-top: 6px; transform-origin: 0px 100%; transition: all 300ms; } .activeline1__bars-menu{ transform: rotate(45deg) translate(-2px, 1px); } .activeline2__bars-menu{ opacity: 0; margin-left: -30px; } .activeline3__bars-menu{ transform: rotate(-45deg) translate(-4px, 1px); } .items-mobile{ gap: 15px; } .icon-mobile-nav svg{ width: 20px; height: 20px; fill: var(--color-travelance); margin-right: 0.3rem; } .title-menu-responsive{ font-size: 0.8rem; color: var(--light-grey01); text-transform: uppercase; letter-spacing: 1px; border-top: 1px solid #DEDFE0; padding-top: 10px; } .div-line{ width: 2px; height: 17px; background-color: #70737A; font-weight: 100; } .div-line-header{ width: 1.5px; height: 10px; background-color: #70737A; font-weight: 100; } .language-mobile{ display: flex; align-items: center; } .travelance-shape{ height: 58px; position: absolute; right: 15px; } .travelance-shape img{ height: 100%; } .club-icon{ width: 20px; height: 20px; border-radius: 50%; background-color: var(--bronze); } .c-b2b-header__club-badge{ display: flex; flex-direction: column; } .c-b2b-header__nav-container{ z-index: 1000; } .back-modal{ display: none; } .container-options-mobile{ display: none; } .link-sidebar a{ color: #000; /* margin: 1rem 0rem !important; */ position: relative; } #link-club-m{ text-decoration: underline; } .items-desktop{ display: flex; } .container-back-modal{ display: flex; align-items: center; justify-content: flex-start; } .container-back-modal button{ border: none; background-color: transparent; cursor: pointer; } .container-back-modal button svg{ width: 10px; fill: var(--color-primary); vertical-align: middle; margin-right: 0.7rem; } .title-origin{ display: flex; align-items: center; color: var(--color-primary); } .container-selection-mobile{ width: 100% !important; height: 100vh; position: absolute; background-color: #fff; top:0; z-index: 1000; padding: 24px; display: none; } .c-b2b-header__language-container button{ border: none; background-color: transparent; cursor: pointer; } .container-selection-mobile .title-origin h3{ font-size: 1rem; } .container-selection-mobile .c-b2b-header__location-selection-list li{ border-bottom: 1px solid #ccc; list-style-type: none; display: flex; align-items: center; justify-content: space-between; } .container-selection-mobile .c-b2b-header__location-selection-list li a{ text-decoration: none; padding-left: 1rem; color: var(--grey); } .content-modal{ position: relative; } .title-level-m{ font-weight: 500; font-size: 14px; } .number-club-m{ font-size: 14px; } .container-close{ width: 100%; /* background-color: #EFF0F1; */ display: flex; align-items: center; justify-content: flex-end; cursor: pointer; } .container-close button{ border: none; background-color: transparent; margin-top: 1rem; margin-right: 1rem; cursor: pointer; } .container-close button svg{ width: 30px; fill: var(--color-primary); } .item-select-responsive{ display: flex; flex-flow: row wrap; align-items: center; justify-content: center; } .item-select-responsive img{ vertical-align: middle; } .item-select-responsive svg{ vertical-align: middle; } .container-link-club svg{ fill: var(--color-travelance); vertical-align: middle; margin-right: 0.5rem; } .icon-eur{ color: var(--color-travelance); } .item-select{ width: 100%; } .container-icon-responsive{ width: 32px; height: 32px; border-radius: 100%; display: -ms-flexbox; display: flex; -ms-flex-pack: center; justify-content: center; -ms-flex-align: center; align-items: center; background-color: white; -ms-flex-negative: 0; flex-shrink: 0; margin-right: 0.7rem; border: 1px solid #c5c5c5; } .container-icon-responsive img{ width: 20px; height: 20px; object-fit: contain; } /* .item-select:not(.item-select:last-child){ border-bottom: 1px solid #DEDFE0; } */ .items-responsive{ padding: 5px 24px 0px 24px; } #item-mobile{ width: 65px; display: none; } #item-mobile svg{ width: 25px; } #item-mobile a{ width: 40px; } .header-partner{ height: 58px; display: flex; align-items: center; padding-left: 1rem; /* background-color: yellow; */ } .header-travelance{ height: 40px; display: flex; align-items: center; justify-content: space-evenly; gap: 25px; } .img-agency{ border-radius: 50%; } .logo-travelance-mobile{ width: 18px !important; display: none; position: absolute; z-index: 1000; } .items-select .c-b2b-header__language-container .c-b2b-header__language-selected{ width: 20px; } #img-responsive{ width: 20px; } .container-club{ background-color: yellow; } .club-responsive{ display: flex; align-items: center; } .c-location-responsive{ display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; cursor: pointer; color: #000; border: none; background-color: transparent; font-size: 16px; vertical-align: middle; } .c-location-responsive svg{ width: 16px; vertical-align: middle; } .c-location-responsive span{ margin-left: 0.3rem; } .currency-responsive{ display: flex; align-items: center; } .currency-responsive button{ border: none; background-color: transparent; cursor: pointer; } .currency-responsive .c-b2b-header__currency-selected{ color: #000; background-color: transparent; font-size: 20px; } .icon-language-responsive{ width: 35px; height: 35px; border-radius: 50%; overflow: hidden; background-color: rgba(255, 255, 255, 0.16); display: -ms-flexbox; display: flex; -ms-flex-pack: center; justify-content: center; -ms-flex-align: center; align-items: center; padding: 7px; } #img-responsive{ border-radius: 50%; overflow: hidden; width: 100%; height: 100%; object-fit: cover; } .log-out-icon{ width: 15px; fill: #fff; vertical-align: middle; margin-right: 0.3rem; } #link-club-m a{ margin-top: 20px; font-size: 14px; color: #70737A; } .subtitle-sidebar{ display: none; } .c-b2b-header__user-mb svg{ display: none; } /* -------------MEDIA QUERIES */ @media (max-width:770px){ #logo-desktop{ display: none; } .c-b2b-header__user-mb svg{ display: block; } .c-b2b-header__top-nav { -ms-flex: 1 1 auto; flex: 1 1 auto; display: -ms-flexbox; display: flex; -ms-flex-align: center; align-items: center; -ms-flex-pack: center; justify-content: center; } .line-header{ display: none; } .subtitle-sidebar{ display: block; } .header-menu-desktop{ display: none; } .bars-menu{ display: block; } .c-b2b-header__user-mb { width: 58px; height: 58px; } .c-b2b-header__nav-container{ width: 80%; display: flex; flex-direction: column; z-index: 1000; } .container-options-mobile{ display: block; } .c-b2b-header__top-left, .c-b2b-header__top-nav, .header-travelance{ width: 33.33%; } .c-b2b-header__user-modal-container{ width: 70%; } .c-b2b-header__top{ height: 58px; background-color: #fff; } .c-b2b-header__user-container{ gap: 0px; } .c-b2b-header__nav{ display: none; } .header-travelance{ align-items: center; justify-content: flex-end; } .option-sidebar-desktop{ display: none; } .c-b2b-header__user-modal-title{ font-size: 15px; } .items-desktop{ display: none; } .logo-travelance-mobile{ display: block; } .img-agency{ display: none; } .c-b2b-header__user-container{ display: flex; justify-content: flex-end; } .c-b2b-header{ box-shadow: 0 1px 3px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.24); transition: all .2s cubic-bezier(.25,.8,.25,.1); } .c-b2b-header__club{ display: none; } .c-b2b-header__location-container{ display: none; } .c-b2b-header__user-modal-btn{ font-size: 14px; } .c-b2b-header__top{ padding: 1rem !important; } } @media(min-width:770px){ .link-sidebar{ display: none; } .c-b2b-header__sidebar { top:89px; height: calc(100% - 89px); } /* .c-b2b-header__sidebar-logo{ display: none; } */ .c-b2b-header__sidebar-menu { top:89px; height: calc(100% - 89px); } .c-b2b-header__sidebar-menu { top:89px; height: calc(100% - 89px); } .c-b2b-header__sidebar-nav { top:89px; height: calc(100% - 89px); } } @media screen and (min-width: 48.125em) { .c-b2b-header__nav-container { position: absolute; top: 58px; width: 100%; display: -ms-flexbox; display: flex; -ms-flex-pack: center; justify-content: center; left: 0; transition: 0.4s all; z-index: 3; left: 15%; } .c-b2b-header__nav-container:not(.is-active) { opacity: 0; pointer-events: none; z-index: -1; } .c-b2b-header__nav-products { padding: 24px; max-height: calc(100vh - 60px); overflow-y: auto; box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1215686275); scrollbar-width: thin; /* "auto" or "thin" */ scrollbar-color: #ededed var(--color-white, #ffffff); /* scroll thumb and track */ transition: 0.6s all; -ms-transform: translateX(0); transform: translateX(0); z-index: 1000; } .c-b2b-header__nav-products::-webkit-scrollbar { width: 7px; } .c-b2b-header__nav-products::-webkit-scrollbar-track { background: #ededed; /* color of the tracking area */ } .c-b2b-header__nav-products::-webkit-scrollbar-thumb { background-color: var(--color-travelance); /* color of the scroll thumb */ border-radius: 2px; /* roundness of the scroll thumb */ border: 2px solid #ededed; } .c-b2b-header__nav-products-list { column-count: 2; } .c-b2b-header__sidebar img, .c-b2b-header__sidebar svg { width: 20px; } /* .c-b2b-header__sidebar { top:88px; height: calc(100% - 88px); } */ .c-b2b-header__sidebar-link.is-desktop-hidden { display: none; } .c-b2b-header__sidebar-logo-full img { max-width: 130px; } .c-b2b-header__sidebar-logo-full:after { top: 38%; width: 8px; height: 8px; } /* .c-b2b-header:not(.is-stuck) .c-b2b-header__sidebar-logo { display: none; } */ .c-b2b-header:not(.is-stuck) .c-b2b-header__sidebar-nav { display: none !important; } .c-b2b-header__sidebar-contact { top:89px; height: calc(100% - 89px); } .c-b2b-header__club-expand { left: calc(50% + 10px); } } @media screen and (min-width: 47.9375em) and (max-width: 89.9375em) { .c-b2b-header__nav-products { max-width: calc(100% - 64px); } } @media screen and (min-width: 64.0625em) { .c-b2b-header__top-logo-mobile { display: none; } .c-b2b-header__top-left { width: 28%; } .c-b2b-header__top-nav-search { width: 400px; } } @media screen and (min-width: 75em) { .c-b2b-header__top-right { gap: 20px; } .c-b2b-header__user-mb { display: none; } .c-b2b-header__nav { -ms-flex-pack: justify; justify-content: space-between; } .c-b2b-header__nav-right { width: 264px; } .c-b2b-header__nav-menu a { padding: 0 16px; } } @media screen and (min-width: 90em) { .c-b2b-header__nav-products { max-width: calc(100% - 132px); } } @media screen and (max-width: 48.125em) { .c-b2b-header__top { padding-right: 0; } .c-b2b-header__top-nav-item{ color: #000; } .c-b2b-header__location-selection { top: 58px; position: fixed; right: 16px; } .c-b2b-header__input { width: 100%; } .c-b2b-header__nav-container { position: fixed; right: -100%; width: 90%; top: 210px; height: calc(100% - 58px); box-shadow: -1px 0px 0px #DEDFE0; background-color: var(--color-white, #ffffff); padding: 15px 10px; overflow-y: auto; scrollbar-width: thin; scrollbar-color: #ededed var(--color-white, #ffffff); transition: 0.6s all; z-index: 1000; } .c-b2b-header__nav-container::-webkit-scrollbar { width: 7px; } .c-b2b-header__nav-container::-webkit-scrollbar-track { background: #ededed; } .c-b2b-header__nav-container::-webkit-scrollbar-thumb { background-color: var(--color-travelance); border-radius: 2px; border: 2px solid #ededed; } .c-b2b-header__nav-container.is-active { right: 0; } .c-b2b-header__nav-container:not(.is-active) { right: -100%; } .c-b2b-header__top-nav-search { position: fixed; top: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.2901960784); left: 0; padding: 308px 16px; z-index: 5; } .c-b2b-header__nav-products-title{ font-size: 14px; } .c-b2b-header__nav-products-link a{ font-size: 13px; } .c-b2b-header__top-nav-search-close { top: 320px; left: 30px; -ms-transform: none; transform: none; } .c-b2b-header__top-nav-search-submit { top: 310px; right: 18px; } .c-b2b-header__nav { display: none; } .c-b2b-header__sidebar { width: 52px; } .c-b2b-header__sidebar-link { gap: 6px; } .c-b2b-header__sidebar-link span { font-size: 12px; text-transform: none; } .c-b2b-header__sidebar-menu { left: 200px; width: calc(100% - 200px); } .c-b2b-header__sidebar-options { left: 200px; width: calc(100% - 200px); } .c-b2b-header__sidebar-menu:not(.is-active) { -ms-transform: translateX(-100%) translateX(-130px); transform: translateX(-100%) translateX(-130px); } .c-b2b-header__sidebar-menu { left: 200px; width: calc(100% - 200px); } .c-b2b-header__sidebar-menu:not(.is-active) { -ms-transform: translateX(-100%) translateX(-130px); transform: translateX(-100%) translateX(-130px); } .c-b2b-header__sidebar-nav { left: 200px; width: calc(100% - 200px); } .c-b2b-header__sidebar-nav:not(.is-active) { -ms-transform: translateX(-100%) translateX(-130px); transform: translateX(-100%) translateX(-130px); } .c-b2b-header__sidebar-contact { left: 200px; width: calc(100% - 200px); } .c-b2b-header__sidebar-contact:not(.is-active) { -ms-transform: translateX(-100%) translateX(-130px); transform: translateX(-100%) translateX(-130px); } /* .c-b2b-header.sidebar-open .c-b2b-header__sidebar { width: 140px; } */ .c-b2b-header__club-info { display: none; } } /* MEDIA VAL */ @media(min-width:770px){ .c-b2b-header__top-logo-mobile{ display: none; } .header-partner{ padding: 0rem 0.5rem; } } @media(max-width:770px){ .c-b2b-header__top{ padding: 0px !important; } .back-modal{ display: block; } .c-b2b-header__top-logo-desktop { display: none; } #item-mobile{ display: block; } .header-partner{ background-color: #fff; } .c-b2b-header__top-left a{ color: var(--color-travelance); } .c-b2b-header__user-modal-container{ z-index: 999; } } @media screen and (max-width: 64em) { .c-b2b-header__top-nav-item { padding: 0 12px; font-size: 14px; } .c-b2b-header__top-right { width: auto; -ms-flex-negative: 0; flex-shrink: 0; gap: 10px; } .c-b2b-header__nav-menu { /*justify-content: flex-end;*/ -ms-flex-positive: 1; flex-grow: 1; } } @media screen and (max-width: 74.9375em) { /* .c-b2b-header__location-selected { width: 34px; height: 34px; border-radius: 50%; display: -ms-flexbox; display: flex; -ms-flex-pack: center; justify-content: center; -ms-flex-align: center; align-items: center; font-size: 12px; background-color: rgba(255, 255, 255, 0.16); letter-spacing: -0.36px; } */ /* .c-b2b-header__location-selected img, .c-b2b-header__location-selected svg { display: none; } */ .c-b2b-header__user-image { display: none; } .c-b2b-header__user-company { display: none; } .c-b2b-header__user-name { display: none; } } .bg-modal { margin-top: 2.5rem; border-top: 1px solid #DEDFE0; padding: 1rem 0rem; } .bg-modal ul li a { padding: 0.5rem 0.5rem; } .bg-modal ul li:last-child { margin-bottom: 1rem; } .search-container input { width: 200px; height: 40px; border: 0 none; font-size: 0.9rem !important; padding: 0.5rem !important; color: #828486; border: 1px solid #d1d1d1; } .search-container input, .search-container .agency-suggestions { width: 100%; background: #fff; text-align: left; } .search-container .agency-suggestions { width: 100%; box-shadow: 0 1px 3px rgba(0, 0, 0, .12), 0 1px 2px rgba(0, 0, 0, .24); transition: all .2s cubic-bezier(.25, .8, .25, .1); } .search-container ul { display: none; max-height: 25.7vh; overflow-y: auto; } .search-container ul li { list-style-type: none; cursor: pointer; padding: 0.7rem 0.7rem 0.7rem 1rem; } .search-container ul li:not(li:last-child) { border-bottom: 0.2px solid rgb(233, 233, 233) !important; } .search-container ul.has-suggestions { display: block; height: 700px; padding-left: 0px !important; } #agency-searcher { margin-top: .6rem; } .progress-bar-head { width: 100%; height: 15px; background-color: var(--light-grey02); position: relative; border-radius: 30px; margin: 1rem 0rem; } .progress-bar-sidebar { width: 100%; height: 15px; background-color: var(--light-grey02); position: relative; border-radius: 30px; margin: 0.8rem 0rem; } .progress-bar-sidebar .level-container-head p { font-weight: normal; margin: 0px !important; } .progress-head { height: 100%; transition: width 0.5s ease; border-radius: 30px; } .icon-head { width: 30px; height: 30px; position: absolute; top: -7px; transform: translateX(-10px) scale(0.87); font-size: 16px; line-height: 30px; color: white; overflow: hidden; white-space: nowrap; transition: left 0.5s ease; } .progress-initial { background-color: var(--initial); } .progress-bronze { background-color: var(--low); } .progress-silver { background-color: var(--medium); } .progress-gold { background-color: var(--premium); } .progress-head-bar_head p { font-size: 0.8rem; } .icon-bronze::before { content: ""; left: 100%; transform: translateX(-100%); } .icon-silver::before { content: url("medium.png"); left: 100%; transform: translateX(-100%); } .icon-gold::before { content: url("premium.png"); left: 100%; transform: translateX(-100%); } .icon-initial::before { content: url("initial.png"); left: 100%; transform: translateX(-100%); } .progress-bar-sidebar .level-container-head{ margin-top: 0.5rem; } .level-container-head { display: flex; flex-direction: row; align-items: center; justify-content: space-between; font-size: 0.8rem; } .level-container-head p { font-weight: normal; } .color-initial { color: var(--initial); } .color-bronze { color: var(--low); } .color-silver { color:var(--medium); } .color-gold { color:var(--premium); } .bronze-bar, .silver-bar { padding: 0.46rem 0.10rem; position: absolute; } .bronze-bar { width: 0.5%; background-color:var(--turquoise); top: 0%; left: 33.33%; z-index: 1; } .silver-bar { width: 0.5%; background-color: var(--blue); top: 0%; left: 66.67%; z-index: 1; } .container-link-club-not-signed { display: flex; align-items: center; justify-content: flex-start; padding: 0.8rem 0rem; } .container-link-club-not-signed a { color: white; font-size: 0.8rem; } .container-link-club { display: flex; align-items: center; justify-content: flex-start; padding: 0.8rem 0rem; } .container-link-club img { width: 15px; margin-right: 10px; } .container-link-club a { color: #1e1e1e; font-size: 0.8rem; margin-top: 1rem; } .container-link-club a i { margin-right: 0.5rem; } @media(min-width:450px) and (max-width:600px){ .c-b2b-header__nav-container{ width: 90%; display: flex; flex-direction: column; align-items: flex-start; } .c-b2b-header__top-logo-mobile{ width: 140px; } } @media(max-width:450px){ .c-b2b-header__top-logo-mobile{ width: 120px; } .logo-travelance-mobile { width: 14px !important; } } /*# sourceMappingURL=b2b-header.css.map */ </style> </head> <body class="has-b2b-header"> <div class="c-b2b-header"> <div class="c-b2b-header__head"> <div class="c-b2b-header__top"> <!-- <div class="header-partner"> --> <div class="c-b2b-header__top-left"> <a class="c-b2b-header__sidebar-link skeleton" href="#" id="item-mobile"> </a> <a href="https://www.soltour.com" id="logo-desktop" class="c-b2b-header__top-logo-desktop skeleton" > <img src=""> </a> </div> <div class="c-b2b-header__top-nav"> <div class="items-desktop skeleton"> <a class="c-b2b-header__top-nav-item js-bookings" href="#"> </a> </div> <div class="c-b2b-header__top-logo-mobile skeleton"> </div> </div> <!-- </div> --> <div class="header-travelance"> <div class="c-b2b-header__top-right"> <div class="line-header"></div> <div class="item-header-travelance"> <div class="c-b2b-header__club"> <div class="c-b2b-header__club-badge skeleton"> <!-- <img src="favicon-travelance.svg"> --> </div> <div class="c-b2b-header__club-info skeleton"> <div class="title-club-header"></div> </div> </div> </div> </div> <div class="line-header"></div> <div class="c-b2b-header__location-container"> <div class="c-b2b-header__location-selected skeleton"> </div> <!-- <div class="div-line-header"></div> --> <div class="c-b2b-header__market-container"> <div class="c-b2b-header__market-selected skeleton"> </div> </div> <!-- <div class="div-line-header"></div> --> <div class="c-b2b-header__currency-container"> <div class="c-b2b-header__currency-selected skeleton"> </div> </div> </div> <div class="line-header"></div> <div class="c-b2b-header__user-container"> <div class="c-b2b-header__user-mb skeleton"> <!-- <img src="https://ui-avatars.com/api/?name=AGENCIAS PENDIENTES DE DEFINIR&amp;background=random" class="img-agency"> --> </div> <div class="c-b2b-header__user-image skeleton"> <!-- <img src="https://ui-avatars.com/api/?name=AGENCIAS PENDIENTES DE DEFINIR&amp;background=random"> --> </div> <div> <div class="c-b2b-header__user-company skeleton"></div> <div class="c-b2b-header__user-name skeleton"></div> </div> </div> </div> </div> <div class="c-b2b-header__nav"> <ul class="c-b2b-header__nav-menu"> <li><a href="#" class="link-desktop skeleton"></a></li> <li><a href="#" class="link-desktop skeleton"></a></li> <li><a href="#" class="link-desktop skeleton"></a></li> <li><a href="" class="link-desktop skeleton"></a></li> <li><a href="" class="link-desktop skeleton"></a></li> <li><a href="" class="link-desktop skeleton"></a></li> <li><a href="" class="link-desktop skeleton"></a></li> <li><a href="" class="link-desktop skeleton"></a></li> <li><a href="" class="link-desktop skeleton"></a></li> <li><a href="" class="link-desktop skeleton"></a></li> <li><a href="" class="link-desktop skeleton"></a></li> <li><a href="" class="link-desktop skeleton"></a></li> <li><a href="" class="link-desktop skeleton"></a></li> <li><a href="" class="link-desktop skeleton"></a></li> <li class="link-more-product js-products link-desktop skeleton"> </li> </ul> </div> <div class="c-b2b-header__nav-container js-products-nav"> <div class="c-b2b-header__nav-products"> <div class="back-modal"> <div class="container-back-modal"> <button class="turn-back"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z"/></svg> </button> </div> </div> <div class="c-b2b-header__nav-products-column"> <img class="c-b2b-header__nav-products-logo" src="https://b2b.soltour.es/sltwww/st4/desktop/images/common/logoNew.svg"> <div class="c-b2b-header__nav-products-list"> <div class="c-b2b-header__nav-products-item"> <div class="c-b2b-header__nav-products-title">Vacaciones</div> <div class="c-b2b-header__nav-products-subtitle"></div> <ul class="c-b2b-header__nav-products-link"> <li><a href="#">Circuitos</a></li> <li><a href="#">Combinados</a></li> <li><a href="#">Caribe</a></li> <li><a href="#">Canarias</a></li> <li><a href="#">Mediterr&#xE1;neo</a></li> <li><a href="#">Baleares</a></li> </ul> </div> <div class="c-b2b-header__nav-products-item"> <div class="c-b2b-header__nav-products-title">Especiales</div> <div class="c-b2b-header__nav-products-subtitle"></div> <ul class="c-b2b-header__nav-products-link"> <li><a href="#">Bah&#xED;a Pr&#xED;ncipe</a></li> <li><a href="#">Golf</a></li> <li><a href="#">Novios</a></li> <li><a href="#">Senior</a></li> <li><a href="#">Grupos</a></li> </ul> </div> <div class="c-b2b-header__nav-products-item"> <div class="c-b2b-header__nav-products-title">Hoteles</div> <div class="c-b2b-header__nav-products-subtitle"></div> <ul class="c-b2b-header__nav-products-link"> <li><a href="#">Todos los hoteles</a></li> <li><a href="#">Islas</a></li> <li><a href="#">Costas</a></li> <li><a href="#">BedBank</a></li> <li><a href="#">Caribe</a></li> </ul> </div> <div class="c-b2b-header__nav-products-item"> <div class="c-b2b-header__nav-products-title">Otros productos</div> <div class="c-b2b-header__nav-products-subtitle"></div> <ul class="c-b2b-header__nav-products-link"> <li><a href="#">Vuelo &#x2B; Hotel</a></li> <li><a href="#">Vuelos</a></li> <li><a href="#">Traslados</a></li> <li><a href="#">Coches</a></li> <li><a href="#">Excursiones</a></li> </ul> </div> </div> </div> </div> </div> </div> <div class="c-b2b-header__sidebar"> <div class="header-menu-desktop"> <a class="c-b2b-header__sidebar-link js-sidebar-menu skeleton" href="#"> <!-- <span class="menu-word">Menu</span> --> </a> </div> <div class="container-menu-sidebar"> <div class="c-b2b-header__user-modal-title subtitle-sidebar js-sidebar-menu skeleton"></div> <div class="container-items-sidebar a-active menu-word"> <a class="c-b2b-header__sidebar-logo a-sidebar" href="#" id="item2-sidebar"> <div class="c-b2b-header__sidebar-logo-full"> <span class="icon-sidebar skeleton"></span> <span class="word-item-sidebar skeleton"></span> </div> </a> <div class="submenu-sidebar"> <a class="link-sidebar-submenu" href="#"> Senior </a> <a class="link-sidebar-submenu" href="#"> Novios </a> <a class="link-sidebar-submenu" href="#"> Vacaciones </a> <a class="link-sidebar-submenu" href="#"> Ofertas </a> <a class="link-sidebar-submenu" href="#"> Hoteles </a> </div> </div> <div class="container-items-sidebar"> <a class="c-b2b-header__sidebar-logo js-sidebar-nav a-sidebar" href="#" id="item2-sidebar"> <div class="c-b2b-header__sidebar-logo-full"> <span class="icon-sidebar skeleton"> </span> <span class="word-item-sidebar skeleton"></span> </div> </a> </div> <div class="container-items-sidebar"> <a class="c-b2b-header__sidebar-logo js-sidebar-nav a-sidebar" href="#" id="item2-sidebar"> <div class="c-b2b-header__sidebar-logo-full"> <span class="icon-sidebar skeleton"></span> <span class="word-item-sidebar skeleton"></span> </div> </a> </div> <div class="container-items-sidebar"> <a class="c-b2b-header__sidebar-logo js-sidebar-nav a-sidebar" href="#" id="item2-sidebar"> <div class="c-b2b-header__sidebar-logo-full"> <span class="icon-sidebar skeleton"></span> <span class="word-item-sidebar skeleton"></span> </div> </a> </div> <div class="container-items-sidebar"> <a class="c-b2b-header__sidebar-logo a-sidebar" href="#" id="club-link"> <div class="c-b2b-header__sidebar-logo-full"> <span class="icon-sidebar skeleton"></span> <span class="word-item-sidebar skeleton"></span> </div> </a> <div class="submenu-sidebar"> <div class="submenu-club"> <div class="title-club-sidebar"> <h5><span class="level-club-sidebar">Nivel: </span><span>Bronce</span></h5> <h5 class="num-level-club">27.700 / 50.000</h5> </div> <div class="container-bar"> <div class="progress-bar-sidebar"> <div class="progress-head progress-Bronce" style="width:60.81%"></div> <div class="icon-head icon-bronze" style="left:60.81%"></div> <div class="level-container-head"> <p class="color-initial">Initial</p> <p class="color-bronze"><span class="bronze-bar"></span>Bronce</p> <p class="color-silver"><span class="silver-bar"></span>Silver</p> <p class="color-gold"><span class="gold-bar"></span>Gold</p> </div> </div> </div> <div class="container-link-club" id="link-club-m"> <a href="https://www.travelpartners.club//set-session?session=fe415456-e207-44e7-9915-c05bd017f6ac&amp;jwt=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkkxeTVTT0doSW93VGc4cEkyZjVaeCJ9.eyJpc3MiOiJodHRwczovL3NvbHRvdXJ0cC5ldS5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8NjQxMDQ4ZjdiZDhjY2RiMDRkY2I0Njc0IiwiYXVkIjpbImh0dHBzOi8vc29sdG91cnRwLmV1LmF1dGgwLmNvbS9hcGkvdjIvIiwiaHR0cHM6Ly9zb2x0b3VydHAuZXUuYXV0aDAuY29tL3VzZXJpbmZvIl0sImlhdCI6MTY5NTA0MzA0MSwiZXhwIjoxNjk1MDg2MjQxLCJhenAiOiJiUGpQZDNGQzllTzhqWFZXMHdCTW5CVTQwakZKMVJpZyIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwifQ.ZmRR5qTwDq5QwycVziAi7N40FJPvVcuXVGDXF7Sa-2H7rjJ-3CcO_qeNOGjOPbEkx67uV7pipfduXRPfvwGSwCaDtLIF7w2NVmfHL4wRE-QmgaSqOyI5-Pg-MZB74kv6uSU5xOIudNsA_5XruSugOUUXMS5PaDjGQmi5U2KEKJrGcapj5aDmRlLAANQlHTcqRK6l9XgHIt9zFPntD-5YYH0S9FWj06N1dnc3sAaGJG4Y1VZHaJso9FMMKWKIBkZ7lzAkshzgSvxzLXoGZJf8sYSwNVe6dPSXKbv-LpDe1BzuU9mTPEJWugybTxbHpI1L4xC0WeTPMjn7eWLtdmzhyg">Accede al club</a> </div> </div> </div> </div> </div> </div> <!-- <div class="c-b2b-header__sidebar-menu"> <div class="c-b2b-header__sidebar-menu-title">Gesti&#xF3;n de maestros</div> <ul class="c-b2b-header__sidebar-menu-section-list"> <li><a href="https://intranet.soltourtp.com/app/roma/pool">Pooles</a></li> <li><a href="https://intranet.soltourtp.com/app/roma/point-of-sale">Puntos de venta</a></li> <li><a href="https://intranet.soltourtp.com/app/roma/user">Usuarios</a></li> <li><a href="https://intranet.soltourtp.com/app/roma/company">Sociedades</a></li> </ul> <div class="c-b2b-header__sidebar-menu-title">Gesti&#xF3;n de maestros</div> <ul class="c-b2b-header__sidebar-menu-section-list"> <li><a href="https://intranet.soltourtp.com/app/roma/pool">Pooles</a></li> <li><a href="https://intranet.soltourtp.com/app/roma/point-of-sale">Puntos de venta</a></li> <li><a href="https://intranet.soltourtp.com/app/roma/user">Usuarios</a></li> <li><a href="https://intranet.soltourtp.com/app/roma/company">Sociedades</a></li> </ul> </div> --> <div class="c-b2b-header__sidebar-options item1-sidebar close-item"> <ul class="c-b2b-header__sidebar-menu-section-list"> <li><a href="https://intranet.soltourtp.com/app/roma/pool">Condiciones del viaje Combinado</a></li> <li><a href="https://intranet.soltourtp.com/app/roma/point-of-sale">Seguros de viajes</a></li> <li><a href="https://intranet.soltourtp.com/app/roma/user">Decreto Ley turismo de excesos</a></li> <li><a href="https://intranet.soltourtp.com/app/roma/company">Hoja de reclamacion</a></li> </ul> </div> <div class="c-b2b-header__sidebar-contact"> <div class="c-b2b-header__sidebar-contact-title">CONTACTA CON NOSOTROS</div> <div class="c-b2b-header__sidebar-contact-subtitle">Tel&#xE9;fono</div> <div class="c-b2b-header__sidebar-contact-description">Contacta con tu Ejecutivo de Ventas, David Biayna Rodr&#xED;guez, llamando al 646 114 035. <a href="tel:646 114 035">646 114 035</a></div> <div class="c-b2b-header__sidebar-contact-subtitle">E-mail</div> <div class="c-b2b-header__sidebar-contact-description">Rellena un formulario y contactaremos a la mayor brevedad posible</div> </div> <div class="c-b2b-header__user-modal"> <div class="c-b2b-header__user-modal-container"> <div class="container-close"> <button class="close-modal" id="closeModal"> <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg> </button> </div> <div class="c-b2b-header__user-modal-profile"> <div class="c-b2b-header__user-modal-icon skeleton"> <!-- <img src="https://ui-avatars.com/api/?name=AGENCIAS PENDIENTES DE DEFINIR&amp;background=random"> --> </div> <div class="container-info-modal"> <div class="c-b2b-header__user-modal-company skeleton"></div> <div class="c-b2b-header__user-modal-name skeleton"></div> <div class="c-b2b-header__user-modal-email skeleton"></div> </div> </div> <!-- <-- CONTENEDOR PADRE --> <div class="content-modal"> <div class="container-options-mobile"> <div class="container-selection-mobile" id="select-country"> <div class=""> <div class="title-origin"> <div class="container-back-modal"> <button class="turn-back" id="turn-back-currency"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z"/></svg> </button> </div> <h3>Elige Pa&#xED;s</h3> </div> <ul class="c-b2b-header__market-selection-list"> <li> <a id="ES" class="is-active"> <span class="c-b2b-header__market-selection-icon"> <img src="https://deal.soltourtp.com/assets/16decae1-19f7-42c5-a40d-b9d29bd22728"> </span>Espa&#xF1;ol </a> </li> <li> <a id="PT" class=""> <span class="c-b2b-header__market-selection-icon"> <img src="https://deal.soltourtp.com/assets/ce00da75-1804-4ad6-8033-8dc23bb77d38"> </span>Portugal </a> </li> </ul> </div> </div> <div class="container-selection-mobile" id="select-currency-mobile"> <div class="title-origin"> <div class="container-back-modal"> <button class="turn-back"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z"/></svg> </button> </div> <h3>Elige moneda</h3> </div> <ul class="c-b2b-header__currency-selection-list list-currency-mobile"> <li> <a class="is-active"> <span class="c-b2b-header__currency-selection-icon"> &#x20AC; </span>Euro </a> </li> <li> <a class=""> <span class="c-b2b-header__currency-selection-icon"> $ </span>Dollar </a> </li> <li> <a class=""> <span class="c-b2b-header__currency-selection-icon"> &#xA3; </span>Pount </a> </li> </ul> </div> <!-- Localidad item --> <div id="location-selection-mobile" class="container-selection-mobile"> <div class="title-origin"> <div class="container-back-modal"> <button id="goBack" class="turn-back"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z"/></svg> </button> </div> <h3>Elige tu aeropuerto mas cercano</h3> </div> <ul class="c-b2b-header__location-selection-list" id="list-mobile"> <li><a data-language="Cor" href="#">A Coruna</a></li> <li><a data-language="Ali" href="#">Alicante</a></li> <li><a data-language="Alm" href="#">AlmeriÃ‚Â­a</a></li> <li><a data-language="Ast" href="#">Asturias</a></li> <li><a data-language="Bad" href="#">Badajoz</a></li> <li><a data-language="Bcn" href="#">Barcelona</a></li> <li><a data-language="Bil" href="#">Bilbao</a></li> <li><a data-language="Bur" href="#">Burgos</a></li> <li><a data-language="Cas" href="#">Castellon</a></li> <li><a data-language="Hie" href="#">El Hierro</a></li> <li><a data-language="Fue" href="#">Fuerteventura</a></li> <li><a data-language="Gir" href="#">Girona</a></li> <li><a data-language="GCa" href="#">Gran Canaria</a></li> <li><a data-language="Gra" href="#">Granada</a></li> <li><a data-language="Ib" href="#">Ibiza</a></li> <li><a data-language="Jer" href="#">Jerez</a></li> <li><a data-language="Gom" href="#">La Gomera</a></li> <li><a data-language="Pal" href="#">La palma</a></li> <li><a data-language="Lan" href="#">Lanzarote</a></li> <li><a data-language="Leo" href="#">Leon</a></li> <li><a data-language="Lle" href="#">Lleida</a></li> <li><a data-language="Log" href="#">Logrono</a></li> <li></i><a class="is-active" data-language="Mad" href="#">Madrid</a></li> <li><a data-language="Mal" href="#">Malaga</a></li> <li><a data-language="Mall" href="#">Mallorca</a></li> <li><a data-language="Mel" href="#">Melilla</a></li> <li><a data-language="Men" href="#">Menorca</a></li> <li><a data-language="Mur" href="#">Murcia</a></li> <li><a data-language="Pam" href="#">Pamplona</a></li> <li><a data-language="Reu" href="#">Reus</a></li> <li><a data-language="Sal" href="#">Salamanca</a></li> <li><a data-language="Sans" href="#">San Sebastian</a></li> <li><a data-language="Sant" href="#">Santander</a></li> <li><a data-language="Comp" href="#">Santiago de Compostela</a></li> <li><a data-language="Sev" href="#">Sevilla</a></li> <li><a data-language="Ten" href="#">Tenerife</a></li> <li><a data-language="Val" href="#">Valencia</a></li> <li><a data-language="Vad" href="#">Valladolid</a></li> <li><a data-language="Vig" href="#">Vigo</a></li> <li><a data-language="Vit" href="#">Vitoria</a></li> <li><a data-language="Zgz" href="#">Zaragoza</a></li> </ul> </div> <!-- ITEMS MIRAR AQUI --> <div class="items-responsive"> <div class="item-select-responsive items-mobile"> <!-- LOCALIDAD --> <div class="container-location-mobile skeleton"> <!-- <button id="openLocationMobile" class="c-location-responsive"> <div> <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 1024 1024"> <path d="M510.4 0C321.6 0 168 153.6 168 342.4c0 128 54.4 278.4 163.2 451.2 51.2 80 105.6 153.6 163.2 224 3.2 3.2 9.6 6.4 16 6.4h3.2c6.4 0 12.8-3.2 16-6.4l3.2-3.2c54.4-67.2 108.8-137.6 156.8-214.4C801.6 620.8 856 467.2 856 342.4 852.8 153.6 699.2 0 510.4 0zm0 518.4c-83.2 0-153.6-70.4-153.6-153.6s70.4-153.6 153.6-153.6c83.2 0 153.6 70.4 153.6 153.6s-70.4 153.6-153.6 153.6z"> </path> </svg> </div> <span>MAD</span> </button> --> </div> <div class="div-line"></div> <!-- LENGUAJE --> <div class="c-b2b-header__language-container language-mobile skeleton"> </div> <div class="div-line"></div> <!-- MONEDA --> <div class="currency-responsive skeleton"> </div> </div> <!-- <div class="item-select-responsive options-bar-mobile"> <a href="#"> <span class="icon-mobile-nav"> <svg id="Capa_1" data-name="Capa 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 95.23 136.04"> <path class="cls-1" d="m81.62,68.02v48.51l-30.24-20.16c-2.29-1.52-5.26-1.52-7.55,0l-30.23,20.16V13.61h81.62c0-7.5-6.11-13.61-13.61-13.61H13.61C6.11,0,0,6.1,0,13.61v115.64c0,2.51,1.38,4.81,3.59,5.99,2.21,1.19,4.9,1.04,6.99-.34l37.04-24.68,37.03,24.68c1.14.76,2.46,1.15,3.77,1.15,1.11,0,2.21-.26,3.21-.81,2.21-1.18,3.6-3.48,3.6-5.99v-61.22h-13.61Z"/> <polygon class="cls-1" points="47.62 80.05 21.2 53.63 33.22 41.61 47.62 56 75.61 28 87.64 40.03 47.62 80.05"/> </svg> </span> Reservas </a> <a href="#" class="js-products" id="btn-booking-mobile"> <span class="icon-mobile-nav"> <svg id="Capa_1" data-name="Capa 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 67.54 61.4"> <path class="cls-1" d="m54.45,36.83h-11.47v-6.14h-6.14v6.14h-12.28v-12.27h6.14v-6.14h-6.14V6.95c1.97-.51,4.02-.8,6.14-.8V0C13.77,0,0,13.77,0,30.7s13.77,30.7,30.7,30.7,30.7-13.77,30.7-30.7h-6.14c0,2.12-.3,4.17-.81,6.14M18.42,9.46v8.96h-8.96c2.15-3.71,5.24-6.8,8.96-8.96m-11.47,15.1h11.47v12.27H6.95c-.51-1.96-.81-4.02-.81-6.14s.3-4.17.81-6.14m2.51,18.42h8.96v8.96c-3.71-2.15-6.8-5.24-8.96-8.96m15.09,11.47v-11.47h12.28v11.47c-1.96.51-4.02.81-6.14.81s-4.17-.3-6.14-.81m18.42-2.51v-8.96h8.96c-2.15,3.71-5.25,6.8-8.96,8.96"/> <path class="cls-1" d="m67.27,4.66c-.68-1.5-2.44-2.22-3.98-1.6l-8.62,3.83L44.48.44l-4.93,2.55,9.58,6.21h.36l-7.46,3.32-6.45-2.88-4.86,2.8,12.28,6.16,6.75-3.12-4.68,12.14,5.52-2.87,6.73-12.29,8.39-3.69c1.58-.69,2.29-2.54,1.58-4.12"/> </svg> </span> Productos </a> </div> --> </div> </div> <div class="c-b2b-header__user-modal-options"> <div class="c-b2b-header__user-modal-select"> <div class="c-b2b-header__user-modal-title skeleton"></div> <div class="search-container skeleton"> <!-- <input id="agency-searcher" name="agency-searcher" type="text" placeholder="AGENCIA" autocomplete="off" value="AGENCIAS PENDIENTES DE DEFINIR"> --> <div class="agency-suggestions"> <ul class=""> </ul> </div> </div> </div> <div class="bg-modal"> <div class="c-b2b-header__user-modal-title skeleton"></div> <ul class="c-b2b-header__user-modal-config-links"> </ul> </div> <div class="c-b2b-header__user-modal-bottom skeleton"> <!-- <a class="c-b2b-header__user-modal-btn" href="https://login.soltourtp.com/logout"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg> Cerrar sesion</a> --> </div> </div> </div> </div> </div> <div class="c-b2b-header__sidebar-nav item2-sidebar close-item"> <ul class="c-b2b-header__sidebar-nav-section-list"> <li><a href="https://intranet.soltourtp.com/app/roma/user" class="link-desktop">Usuarios</a></li> <li><a href="https://intranet.soltourtp.com/app/roma/point-of-sale" class="link-desktop" >Puntos de venta</a></li> <li><a href="https://intranet.soltourtp.com/app/roma/pool" class="link-desktop">Pooles</a></li> <li><a href="https://intranet.soltourtp.com/app/roma/company" class="link-desktop">Sociedades</a></li> </ul> </div> </div> </body> </html>'

  var request = new XMLHttpRequest();

  setInterval(SessionRefresh(session, netherUrl), 600 * 1000);

  request.open(
    "GET",
    netherUrl + "/osiris/render/header-stp-b2b?session=" +
    session,
    true
  );

  request.setRequestHeader("Content-Type", "application/json");

  request.onload = function () {
    if (this.status >= 200 && this.status < 400) {
      var rs = JSON.parse(this.response);
      var container = document.getElementById("header-stp-b2b-container");
      AddDataLayer(rs.dataLayer)
      container.innerHTML = rs.html;
      start();
    } else {
      console.error("Error loading the navigation bar");
    }
  };

  request.onerror = function () {
    console.error("Error making the request to the navigation bar");
  };

  request.send();

  function start() {
    loadAgencySelector(session, netherUrl);
    emitEvents();
    LoadPointOfSaleImpersonated();

    var header = document.querySelector(".c-b2b-header");
    var locationOpen = document.getElementsByClassName(
      "c-origin"
    );

    var locationContainer = document.getElementsByClassName(
      "overlay-gallery-B2B"
    );

    var btnOriginsText = document.querySelectorAll('#button-open-text-origins')

    var closeOrigins = document.querySelectorAll('#close-desk')

    var locationItems = document.querySelector(
      ".c-b2b-header__location-selection-list-B2B li"
    );

    var marketOpen = document.getElementsByClassName(
      "c-b2b-header__market-container"
    );

    var marketContainer = document.getElementsByClassName(
      "c-b2b-header__market-selection"
    );

    var marketItems = document.querySelector(
      ".c-b2b-header__market-selection-list a"
    );

    var curOpen = document.getElementsByClassName(
      "c-b2b-header__currency-container"
    );

    var curContainer = document.getElementsByClassName(
      "c-b2b-header__currency-selection"
    );

    var curItems = document.querySelector(
      ".c-b2b-header__currency-selection-list a"
    );

    var userModal = document.querySelector(".c-b2b-header__user-modal");
    var userContainer = document.querySelector(".c-b2b-header__user-container");
    var userModalContainer = document.getElementsByClassName(
      "c-b2b-header__user-modal-container"
    );

    var productsContainer = document.querySelector(".js-products-nav");
    var topNavContainer = document.querySelector(".c-b2b-header__top-nav");

    var closehModal = document.getElementsByClassName(
      "c-b2b-header__top-nav-search-close"
    );

    var clubOpen = document.getElementsByClassName("c-b2b-header__club");
    var clubContainer = document.getElementsByClassName(
      "c-b2b-header__club-expand"
    );

    var sidebarContainer = document.getElementsByClassName("c-b2b-header__sidebar");

    var sidebarMenu = document.querySelector(".js-sidebar-menu");

    if (document.querySelectorAll("#b2b-header__editor-mode").length > 0) {
      var editorModeButton = document.getElementById('b2b-header__editor-mode');
      editorModeButton.addEventListener('click', EditorModeEvent);
    }

    if (locationContainer.length > 0) {
      closeOrigins[0].addEventListener("click", function () {
        locationContainer[0].classList.remove("is-active");
      });

      locationOpen[0].addEventListener("click", function () {
        locationContainer[0].classList.toggle("is-active");
      });

      if (btnOriginsText.length > 0) {
        btnOriginsText[0].addEventListener("click", function () {
          locationContainer[0].classList.toggle("is-active");
        });
      }

      for (var i = 0; i < locationItems.length; i++) {
        locationItems[i].addEventListener("click", function () {
          locationContainer[0].classList.remove("is-active");
        });
      }
    }

    if (marketContainer.length > 0) {
      marketOpen[0].addEventListener("click", function () {
        marketContainer[0].classList.toggle("is-active");
      });

      for (var i = 0; i < marketItems.length; i++) {
        marketItems[i].addEventListener("click", function () {
          marketContainer[0].classList.remove("is-active");
        });
      }
    }

    if (curContainer.length > 0) {
      curOpen[0].addEventListener("click", function () {
        curContainer[0].classList.toggle("is-active");
      });
      for (var i = 0; i < curItems.length; i++) {
        curItems[i].addEventListener("click", function () {
          curContainer[0].classList.remove("is-active");
        });
      }
    }

    userModal.addEventListener("click", function (e) {
      if (outsideClick(e, userModalContainer)) {
        userModal.classList.remove("is-active");
      }
    });

    if (clubOpen.length > 0) {
      clubOpen[0].addEventListener("click", function () {
        if (clubContainer.length > 0) {
          clubContainer[0].classList.toggle("is-active");
        }
      });
    }

    function toggleProductsMenu(e) {
      e.stopPropagation();
      e.preventDefault();
      productsContainer.classList.toggle("is-active");
    }

    if (document.getElementById("more-products-link") != null) {
      document.getElementById("more-products-link").addEventListener("click", toggleProductsMenu)
    }

    function openSideBar(){
      header.classList.add("sidebar-open")
      sidebarContainer[0].classList.add("c-b2b-header__sidebar-overflow-y")
    }

    function closeSideBar(){
      header.classList.remove("sidebar-open")
      sidebarContainer[0].classList.remove("c-b2b-header__sidebar-overflow-y")
    }

    var searchContainer = document.querySelectorAll('.search-container')

    window.addEventListener("click", function (e) {
      if (outsideClick(e, locationOpen) && outsideClick(e, btnOriginsText)) {
        if (locationContainer.length > 0) {
          let element = e.target;
          let close = true;
          while (element && element.parentNode) {
            element = element.parentNode;
            if (element.classList && element.classList.contains("overlay-gallery-B2B")) {
              close = false;
              break;
            }
            if(element.classList && element.classList.contains("origin-input-popup")){
              close = false;
              break;
            }
          }

          if (close) locationContainer[0].classList.remove("is-active");
        }
      }

      if (outsideClick(e, marketOpen)) {
        if (marketContainer.length > 0) {
          marketContainer[0].classList.remove("is-active");
        }
      }

      if (outsideClick(e, curOpen)) {
        if (curContainer.length > 0) {
          curContainer[0].classList.remove("is-active");
        }
      }

      if (outsideClick(e, productsContainer)) {
        productsContainer.classList.remove("is-active");
      }

      if (outsideClick(e, clubOpen)) {
        if (clubContainer.length > 0) {
          clubContainer[0].classList.remove("is-active");
        }
      }

      if (outsideClick(e, sidebarContainer)) {
        closeSideBar();
        closeAllOptionsSidebar();
        if (document.querySelectorAll('.activeline1__bars-menu').length > 0) {
          showMobileLineBars();
        }
      }

      if (outsideClick(e, searchContainer)) {
        if (searchContainer.length > 0) {
          var agencySuggestions = document.querySelectorAll('div.agency-suggestions ul')
          agencySuggestions[0].classList.remove("has-suggestions")
        }
      }
    });

    userContainer.addEventListener("click", function () {
      userModal.classList.toggle("is-active");
    });

    if (closehModal.length > 0) {
      closehModal.addEventListener("click", function () {
        topNavContainer.classList.toggle("is-active");
      });
    }

    sidebarMenu.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();

      productsContainer.classList.remove("is-active");
      if (!header.classList.contains("sidebar-open")) {
        openSideBar()
      } else {
        closeSideBar();
        closeAllOptionsSidebar();
      }
    });

    var sidebarImage = document.querySelectorAll(".img-sidebar")

    sidebarImage.forEach(image => {
        image.addEventListener("click", function (e) {
            e.preventDefault();
            e.stopPropagation();

            productsContainer.classList.remove("is-active");

            if (!header.classList.contains("sidebar-open")) {
                openSideBar();
                openSidebarOption(image);
            } else {
                closeSideBar();
                closeAllOptionsSidebar();
            }
        });
    }) 

    function openSidebarOption(option){
      var parentContainer = option.closest(".container-items-sidebar");
      var submenuSidebar = parentContainer.querySelector(".submenu-sidebar");
      var logoFull = parentContainer.querySelector(".c-b2b-header__sidebar-logo-full:not(.link-sidebar)");
      submenuSidebar.classList.add("active");
      logoFull.classList.add("rotated");
    }

    function outsideClick(event, notelem) {
      var clickedOut = true;
      var length = notelem.length;
      for (var i = 0; i < length; i++) {
        if (event.target == notelem[i] || notelem[i].contains(event.target)) {
          clickedOut = false;
        }
      }
      return clickedOut ? true : false;
    }

    document.querySelector("#item-mobile").addEventListener("click", showMobileLineBars);
    var line1__bars = document.querySelector(".line1__bars-menu");
    var line2__bars = document.querySelector(".line2__bars-menu");
    var line3__bars = document.querySelector(".line3__bars-menu");

    function showMobileLineBars() {
      line1__bars.classList.toggle("activeline1__bars-menu");
      line2__bars.classList.toggle("activeline2__bars-menu");
      line3__bars.classList.toggle("activeline3__bars-menu");
    };

    var itemMobileLink = document.getElementById('item-mobile');

    itemMobileLink.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      header.classList.toggle("sidebar-open");
      sidebarContainer[0].classList.toggle("c-b2b-header__sidebar-overflow-y");
      if (document.querySelector(".close-item.is-active")) {
        document.querySelector(".close-item.is-active").classList.remove('is-active')
      }
    });

    if (document.querySelectorAll("#location-selection-mobile").length > 0) {
      var openLocationMobileBtn = document.getElementById('openLocationMobile');
      var locationMobileContainer = document.getElementById('location-selection-mobile');
      var goBackBtn = document.getElementById('goBack');
      openLocationMobileBtn.addEventListener('click', function () {
        locationMobileContainer.style.display = 'block';
      });
      goBackBtn.addEventListener('click', function () {
        locationMobileContainer.style.display = 'none';
      });
    }

    if (document.querySelectorAll("#select-country").length > 0) {
      document.querySelector('.icon-language-responsive').addEventListener('click', function () {
        var container = document.getElementById('select-country');
        container.style.display = 'block';
      });

      if (document.querySelectorAll("#turn-back-currency").length > 0) {
        document.getElementById('turn-back-currency').addEventListener('click', function () {
          var container = document.getElementById('select-country');
          container.style.display = 'none';
        });
      }
    }

    // Obten una referencia al boton con el id "closeModal"
    var closeModalButton = document.getElementById('closeModal');
    // Agrega un evento de clic al boton para quitar la clase "is-active"
    closeModalButton.addEventListener('click', function () {
      // Obten una referencia al elemento con la clase "c-b2b-header__user-modal"
      var userModal = document.querySelector('.c-b2b-header__user-modal');
      // Quita la clase "is-active"
      userModal.classList.remove('is-active');
    });

    var sidebarItems = document.querySelectorAll(".js-sidebar-nav");
    sidebarItems.forEach(function (sidebarItem) {
      var item = document.getElementsByClassName(sidebarItem.id)[0];
      sidebarItem.addEventListener("click", function () {
        if (item.classList.contains('is-active')) {
          item.classList.remove('is-active')
        } else {
          if (document.querySelector(".close-item.is-active")) {
            document.querySelector(".close-item.is-active").classList.remove('is-active')
          }
          item.classList.add('is-active')
        }
      });
    });

    if (document.querySelectorAll('#select-currency-mobile').length > 0) {
      document.getElementById('btn-currency-mobile').addEventListener('click', function () {
        var container = document.getElementById('select-currency-mobile');
        container.style.display = 'block';
      });

      document.querySelectorAll('.turn-back').forEach(function (button) {
        button.addEventListener('click', function () {
          var container = document.getElementById('select-currency-mobile');
          container.style.display = 'none';
        });
      });
    }

    var aSidebars = document.querySelectorAll(".a-sidebar");

    aSidebars.forEach(function (aSidebar) {
      aSidebar.addEventListener("click", function (event) {
        event.preventDefault();
        if(!header.classList.contains("sidebar-open")) openSideBar();

        var parentContainer = this.closest(".container-items-sidebar");
        var submenuSidebar = parentContainer.querySelector(".submenu-sidebar");
        var logoFull = parentContainer.querySelector(".c-b2b-header__sidebar-logo-full:not(.link-sidebar)");

        submenuSidebar.classList.toggle("active");
        logoFull.classList.toggle("rotated");
      });
    });

    function closeAllOptionsSidebar(){
      var aSidebars = document.querySelectorAll(".a-sidebar");

      aSidebars.forEach(function (aSidebar) {
        var parentContainer = aSidebar.closest(".container-items-sidebar");
        var submenuSidebar = parentContainer.querySelector(".submenu-sidebar");
        var logoFull = parentContainer.querySelector(".c-b2b-header__sidebar-logo-full:not(.link-sidebar)");

        if(parentContainer.id != "b2b-header__editor-mode"){
          submenuSidebar.classList.remove("active");
          logoFull.classList.remove("rotated");
        }
      })
    }

    var navList = document.querySelector('.c-b2b-header__nav-menu');
    var initialLoad = true;

    function adjustStyles() {
      var moreProductsNavUl = document.querySelector('.list-more-products-nav ul');
      var navItems = Array.from(navList.querySelectorAll('li:not(#more-products-link)'));

      var maxVisibleItems = calculateMaxVisibleItems();

      if (maxVisibleItems == navItems.length) {
        document.getElementById('more-products-link').classList.add('hidden');
      } else {
        document.getElementById('more-products-link').classList.remove('hidden');
        if (document.querySelector('.js-products-nav').classList.contains('is-active')) {
          document.querySelector('.js-products-nav').classList.remove('is-active')
        }
      }

      navItems.splice(maxVisibleItems, navItems.length).forEach(function (item) {
        var li = document.createElement('li');
        li.appendChild(item.cloneNode(true));
        if (initialLoad) {
          moreProductsNavUl.appendChild(li);
        } else {
          moreProductsNavUl.insertBefore(li, moreProductsNavUl.firstChild);
        }
        item.classList.add('hidden');
      });

      initialLoad = false;
      navItems = Array.from(navList.querySelectorAll('li:not(#more-products-link)'));

      navItems.splice(0, maxVisibleItems).forEach(function (item) {
        item.classList.remove('hidden');
      });

      navItems = Array.from(navList.querySelectorAll('li:not(#more-products-link)'));
      var hiddenLiList = moreProductsNavUl.querySelectorAll("li");
      hiddenLiList.forEach(function () {
        var hiddenLiList = moreProductsNavUl.querySelectorAll("li");
        if (hiddenLiList.length > ((navItems.length - maxVisibleItems) * 2)) {
          moreProductsNavUl.removeChild(hiddenLiList[0]);
        }
      });
    }

    function postionHiddenList() {
      var moreProductButton = document.querySelector('.c-b2b-header__nav-menu #more-products-link');
      var moreProductButtonPosition = moreProductButton.getBoundingClientRect();
      var hiddenList = document.querySelector('.c-b2b-header__nav-products');
      hiddenList.style.position = "absolute";
      hiddenList.style.left = (moreProductButtonPosition.left - moreProductButton.offsetWidth - 30) + "px";
    }

    function calculateMaxVisibleItems() {
      if (window.innerWidth > 770) {
        var navbar = document.getElementsByClassName("c-b2b-header__nav")[0];
        var navLiList = document.querySelectorAll(".c-b2b-header__nav-menu li:not(#more-products-link)");
        var liListWidth = 0;
        var maxVisibleButtons = 0;
        navLiList.forEach(function (item) {
          liListWidth += item.offsetWidth

          if (liListWidth < (navbar.offsetWidth - 200)) {
            maxVisibleButtons++;
          }
        })

        return maxVisibleButtons;
      }
    }

    if (document.getElementById("more-products-link") != null) {
      // Llamar a la funcion una vez al inicio para manejar el estado inicial
      adjustStyles();
      postionHiddenList();

      // Ajustar los estilos al cargar la pagina y al cambiar el tamano de la pantalla
      window.addEventListener('resize', adjustStyles);
      window.addEventListener('resize', postionHiddenList);
    }

  }
}